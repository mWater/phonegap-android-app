function Application(opts) {
    var that = this;
    var version = "30";

    // Setup options
    opts = _.extend({
        localDb : true,
        serverUrl : "http://data.mwater.co/mwater/apiv2/",
        cacheImages : true,
        anchorState : true,
        initialPage : "Main",
        initialPageArgs : [],
        requireLogin : true,
        pageContainer : $("#page_container"),
        actionbar : undefined
    }, opts);

    // Create sync server
    var syncServer = new SyncServer(opts.serverUrl);

    // Open database
    var syncClient;
    if (opts.localDb) {
        var db = window.openDatabase("mwater", "1.0", "mWater", 1000000);

        // Create sync database
        this.syncDb = new SyncDb(db, MWaterSqlModel.tableDefs);

        // Create model
        this.model = new MWaterSqlModel(db, this.syncDb);

        // Create sync client
        syncClient = new SyncClient(this.syncDb, syncServer);
    } else {
        this.model = new MWaterApiModel(syncServer);
    }

    // Create problem reporter
    ProblemReporter.register(opts.serverUrl, version, function() {
        return syncServer.getClientUid();
    });

    // Create source code manager
    var sourceCodeManager = new SourceCodeManager(syncServer);

    // Create authorizer
    var auth = {
        canEdit : function(row) {
            return row.created_by == syncServer.getUsername();
        },
        canDelete : function(row) {
            return row.created_by == syncServer.getUsername();
        },
        canAdd : function(table) {
            return syncServer.loggedIn();
        }

    }

    // Load pages dynamically
    function pagerOnLoad(name, success, error) {
        if (pages && pages[name])
            success(pages[name]);
        else {
            jQuery.getScript("pages/" + name + ".js", function() {
                success(pages[name]);
            }).fail(function(jqxhr, settings, exception) {
                error(exception);
            });
        }
    }

    function error(err) {
        var errStr = "Unknown";
        if (err)
            errStr = err.message || err.code || err.statusText
        alert("Error: " + errStr)
        console.error(JSON.stringify(err));
    }

    if (opts.cacheImages) {
        var imageManager = new CachedImageManager(syncServer, "Android/data/co.mwater.clientapp/images");
    } else {
        var imageManager = new SimpleImageManager(syncServer);
    }
    
    this.createTemplate = function() {
        // Create template engine
        dust.onLoad = function(name, callback) {
            // Load from template
            $.get('templates/' + name + '.template', null, function(data) {
                callback(null, data);
            }, "text").error(function(error) {
                callback(error);
            });
        };
    
        var base = dust.makeBase({
            date : function(chunk, context, bodies, params) {
                function pad2(number) {
                    return (number < 10 ? '0' : '') + number
                }
    
                var d = new Date(params.value * 1000);
                return chunk.write(d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()));
            },
            loc : function(chunk, context, bodies, params) {
                if (params.field)
                    return chunk.write(i18n.localizeField(params.field, params.value));
                return chunk;
            }
    
        });
    
        return function(name, view, callback) {
            dust.render(name, base.push(view), function(err, out) {
                if (err)
                    error(err);
                else {
                    if ( typeof callback == "function")
                        callback(out);
                    else
                        callback.html(out);
                }
            });
        }
    };

    imageManager.init(function() {
        that.model.init(function() {
            // Create pager
            that.pager = new Pager(opts.pageContainer, {
                model : that.model,
                template : that.createTemplate(),
                syncClient : syncClient,
                syncServer : syncServer,
                imageManager : imageManager,
                sourceCodeManager : sourceCodeManager,
                error : error,
                auth : auth,
                appVersion : version
            }, opts.actionbar);

            that.pager.onLoad = pagerOnLoad;

            if (opts.anchorState) {
                // Save state to anchor
                that.pager.onStateChanged = function(state) {
                    window.location.href = "#" + JSON.stringify(state);
                };
            }

            // Listen for back button
            if (window.device && window.device.platform == "Android") {
                document.addEventListener("backbutton", function() {
                    that.pager.closePage();
                }, false);
            }

            // Check if logged in
            if (opts.requireLogin && !syncServer.loggedIn())
                that.pager.loadPage("Login", [function() {
                    that.pager.closePage(opts.initialPage, opts.initialPageArgs);
                }]);
            else if (opts.anchorState && window.location.hash)// Restore state if possible
                that.pager.setState(JSON.parse(decodeURIComponent(window.location.hash.substr(1))));
            else
                that.pager.loadPage(opts.initialPage, opts.initialPageArgs);

            // Check welcome message
            if (syncServer.loggedIn()) {
                syncServer.getWelcome(version, function(valid, message, fatal) {
                    if (!valid) {
                        // Force logout
                        syncServer.manualLogin("", "");
                        
                        // Go to login screen
                        that.pager.closePage("Login", [function() {
                            that.pager.closePage(opts.initialPage, opts.initialPageArgs);
                        }]);
                       return;
                    }                    
                    if (message)
                        alert(message);
                    if (fatal)
                        alert("Please exit application!");
                });
            }
        }, error);
    }, error);
}

/* Static launch funciton */
Application.launch = function() {
    isCordova = utils.parseQuery().cordova;
    isIPhone = navigator.userAgent.toLowerCase().indexOf('iphone') != -1;
    
    // Offline db only on iphone or if explicit
    offlineDb = utils.parseQuery().offline || isCordova || isIPhone;

    function onDeviceReady() {
        $(function() {
            configureDevice();

            var opts = {
                actionbar : window.actionbar,
                localDb : offlineDb,
                cacheImages : isCordova
            };
            // Uncomment next line to use local server
            // opts.serverUrl = "/mwater/apiv2/";
                
            application = new Application(opts);
        });
    }

    function configureDevice() {
        // Handle special cases for not in Cordova
        if (!window.device || window.device.platform != "Android") {
            actionbar = new HtmlActionbar($("body"), {
                defaultTitle : "mWater"
            });
        }
    }

    // If Cordova, wait for deviceready
    if (isCordova) {
        document.addEventListener("deviceready", onDeviceReady, false);
    } else {
        onDeviceReady();
    }
}
function GeoLoadTracker() {
	var loads = []

	this.reset = function() {
		loads = [];
	}

	this.getNeeded = function(rect) {
		var best;
		_.each(loads, function(l) {
			// Check if useful
			if (l.rect.contains(rect)) {
				// If complete
				if (!l.until)
					best = null;
				if (best === undefined || (l.until !== null && l.until > best))
					best = l.until;
			}
		});
		if (best)
			return [{
				rect : rect,
				since : best
			}];
		if (best === null)
			return [];
		return [{rect:rect, since: null}];
	}

	// Check if a supercedes b
	function supercedes(a, b) {
		return a.rect.contains(b.rect) && (!a.until || a.until > b.until);
	}

	this.recordLoaded = function(rect, until) {
		var load = { rect: rect, until: until || null };
		
		// Ignore if superceded
		var superceded = _.any(loads, function(l) { return supercedes(l, load) });
		if (superceded)
			return;

		// Remove any contained that are lesser or equal
		loads = _.filter(loads, function (l) {
		  	return !supercedes(load, l);
		});

		// Add new load
		loads.push(load);
	}

}
/* Actionbar implemented in html in iOS style within twitter bootstrap navbar */
var HtmlActionbar = function(container, opts) {
	opts = _.extend({
		defaultTitle : '',
		fixedTop : true,
	}, opts || {});

	// Create sync server
	var menuCallback; 
	
	var html = '<div class="navbar navbar-inverse' + (opts.fixedTop ? ' navbar-fixed-top' : '" style="position: relative') + '">';
    html+='<a class="btn btn-navbar dropdown-toggle pull-right" data-toggle="dropdown" id="navbar_dropdown_button"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a>';
    html+='<ul class="dropdown-menu pull-right" id="navbar_items_dropdown" role="menu"></ul>'
    html+='<ul class="nav pull-right" id="navbar_items"></ul>';
	html+='<div class="navbar-inner" style="text-align:center; padding-left:0px">';
	html+='<a class="btn-back pull-left" href="#">Back</a>';
    html+='<span class="brand" id="navbar_brand" style="float:none; color:white"><span id="navbar_title"></span></span></div></div>';
    
	var navbar = $(html);
            
	container.prepend(navbar);
	if (opts.fixedTop)
		container.css("padding-top", "40px");

	navbar.find(".btn-back").on("tap", function() {
		if (menuCallback)
			menuCallback("home");
		return false;
	});
	
	$('a.dropdown-toggle, .dropdown-menu a').on('touchstart', function(e) {
  		e.stopPropagation();
	});
	
	this.menu = function(items, callback) {
		menuCallback = callback;
		
		navbar.find("#navbar_items").html('');
		navbar.find("#navbar_items_dropdown").html('');
		navbar.find("#navbar_dropdown_button").hide();
		
		_.each(items, function(item) {
			if (item.ifRoom) {
				var nitem = $('<li><a href="#">' + (item.icon ? '<img height="20" width="20" src="' + item.icon + '">' : item.title) + '</a></li>')
				nitem.click(function(e) {
					navbar.find('[data-toggle="dropdown"]').parent().removeClass('open');
					callback(item.id);
					return false;
				});
				navbar.find("#navbar_items").append(nitem);
			}
			else {
				var nitem = $('<li><a href="#">' + (item.icon ? '<img height="20" width="20" src="' + item.icon + '">' : '') + item.title + '</a></li>')
				nitem.on("tap", function(e) {
					navbar.find('[data-toggle="dropdown"]').parent().removeClass('open');
					callback(item.id);
					return false;
				});
				navbar.find("#navbar_dropdown_button").show();
				nitem.addClass("dropdown");
				navbar.find("#navbar_items_dropdown").append(nitem);
			}
		});
	};

	this.title = function(title) {
		navbar.find("#navbar_title").text(title ? title : opts.defaultTitle);
	};

	this.up = function(enabled, prevTitle) {
		if (enabled) {
			navbar.find(".btn-back").show();
			navbar.find(".btn-back").text(prevTitle ? prevTitle : opts.defaultTitle).show();
		}
		else
			navbar.find(".btn-back").hide();
	};

}
/* cachePath: e.g. "Android/data/co.mwater.clientapp/images" */
function CachedImageManager(syncServer, cachePath) {
	this.syncServer = syncServer;
	this.cachePath = cachePath;
	var that = this;
	var fileTransfer = new FileTransfer();
	var fileSystem = null;

	function createDirs(baseDirEntry, path, success, error) {
		var segs = path.split("/");
		if (segs.length == 1)
			baseDirEntry.getDirectory(segs[0], {
				create : true
			}, success, error);
		else
			baseDirEntry.getDirectory(segs[0], {
				create : true
			}, function(dir) {
				createDirs(dir, segs.slice(1).join("/"), success, error);
			}, error);
	}

	// Gets a directory, creating if necessary. Call success with dirEntry
	function getDirectory(dir, success, error) {
		createDirs(fileSystem.root, dir, success, error);
	}

	function downloadImage(imageUid, url, dirEntry, success, error) {
		fileTransfer.download(encodeURI(url), dirEntry.fullPath + "/" + imageUid + ".jpg", function(entry) {
			success(entry.toURL());
		}, function(err) {
		    // Delete file on disk if present
		    dirEntry.getFile(imageUid + ".jpg", {}, function(imageFile) {
		        imageFile.remove(function() {}, function() {});
		    }, function() {});
		 
            // Call error function
		    error(err);
		});
	}

	function findImageFile(dir, imageUid, found, notfound, error) {
		console.log("checking in: " + dir);

		// Get directory
		getDirectory(dir, function(dirEntry) {
			// Get file if present
			dirEntry.getFile(imageUid + ".jpg", {}, function(imageFile) {
				// File present, display file
				found(imageFile.toURL());
			}, function(err) {
				if (err.code == FileError.NOT_FOUND_ERR)
					notfound();
				else
					error(err);
			});
		}, error);
	}

	function loadOrDownloadImage(dirs, remoteUrl, downloadDir, imageUid, success, error) {
		// If no directories left to try, call download
		if (dirs.length == 0) {
			getDirectory(downloadDir, function(dirEntry) {
				downloadImage(imageUid, remoteUrl, dirEntry, success, error);
			}, error);
			return;
		}

		// Try each directory in dirs, using recursion
		findImageFile(_.first(dirs), imageUid, function(url) {// Found
			success(url);
		}, function(url) {// Not found
			loadOrDownloadImage(_.rest(dirs), remoteUrl, downloadDir, imageUid, success, error);
		}, error);
	}

	/* Gets an image thumbnail, calling success with url */
	this.getImageThumbnailUrl = function(imageUid, success, error) {
		console.log("displayImageThumbnail:" + imageUid);
		loadOrDownloadImage([this.cachePath + "/cached/thumbnail", this.cachePath + "/cached/original", this.cachePath + "/pending/original"], syncServer.getImageThumbnailUrl(imageUid), this.cachePath + "/cached/thumbnail", imageUid, success, error);
	}

	/* Gets an image, calling success with url */
	this.getImageUrl = function(imageUid, success, error) {
		console.log("displayImage:" + imageUid);
		loadOrDownloadImage([this.cachePath + "/cached/original", this.cachePath + "/pending/original"], syncServer.getImageUrl(imageUid), this.cachePath + "/cached/original", imageUid, success, error);
	}


	this.addImage = function(uri, photoUid, success, error) {
		// TODO is this a url passed in or a file?
		fileSystem.root.getFile(uri, null, function(fileEntry) {
			// Copy file to pending folder
			getDirectory(that.cachePath + "/pending/original", function(dirEntry) {
				console.log("Moving file to: " + dirEntry.fullPath + "/" + photoUid + ".jpg");
				fileEntry.moveTo(dirEntry, photoUid + ".jpg", success, error);
			}, error);
		}, error);
	}

	// Upload one image to server. Progress is called with (number of images, % complete). Success is called
	// with number of images remaining.
	this.uploadImages = function(progress, success, error) {
		// Copy file to pending folder
		getDirectory(that.cachePath + "/pending/original", function(dirEntry) {
			// Get a list of all the entries in the directory
			dirEntry.createReader().readEntries(function(files) {
				if (files.length == 0) {
					success(0);
					return;
				}

				// Call progress
				progress(files.length, 0);

				// Upload file
				var ft = new FileTransfer();
				ft.upload(files[0].fullPath, encodeURI(syncServer.getImageUrl(files[0].name.split(".")[0])), function() {
					// Success uploading, delete file
					files[0].remove(function() {
						// File removed, call success
						success(files.length - 1);
					}, error);
				}, function(fileTransferError) {
					if (fileTransferError.http_status == 409) {
						// Image already exists, delete file
						// Success uploading, delete file
						files[0].remove(function() {
							// File removed, call success
							success(files.length - 1);
						}, error);
					} else
						error(fileTransferError);
				}, {
					fileKey : "image",
					params: {"clientuid" : syncServer.getClientUid()}
				});
			}, error);
		}, error);
	}


	this.init = function(success, error) {
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs) {
			fileSystem = fs;
			success();
		}, error);
	}

}

function SimpleImageManager(syncServer) {
	this.init = function(success, error) {
		success();
	}


	this.getImageThumbnailUrl = function(imageUid, success, error) {
		success(syncServer.getImageThumbnailUrl(imageUid));
	}


	this.getImageUrl = function(imageUid, success, error) {
		success(syncServer.getImageUrl(imageUid));
	}

}
function MWaterApiModel(syncServer) {
	var that = this;

	this.init = function(success, error) {
		success();
	};

	this.transaction = function(callback, error, success) {
		var tx = {
			jqXhrs : [],
		};
		callback(tx);
		$.when.apply(window, tx.jqXhrs).done(success).fail(error);
	}

	function makeUrl(addr) {
		return syncServer.baseUrl + addr + "?clientuid=" + syncServer.getClientUid();
	}


	this.insertRow = function(tx, table, values) {
		tx.jqXhrs.push($.ajax(makeUrl(table + "/" + values.uid), {
			type : "PUT",
			data : values,
		}));
	}


	this.updateRow = function(tx, row, values) {
		tx.jqXhrs.push($.ajax(makeUrl(row.table + "/" + row.uid), {
			type : "POST",
			data : values,
		}));
	}


	this.deleteRow = function(tx, row) {
		tx.jqXhrs.push($.ajax(makeUrl(row.table + "/" + row.uid), {
			type : "DELETE",
		}));
	}

	function Row(table) {
		this.table = table;
	}

	function rowifyArray(array, table) {
		for (var i = 0; i < array.length; i++)
			_.extend(array[i], new Row(table));
		return array;
	}


	this.queryNearbySources = function(latitude, longitude, search, success, error) {
		console.log("Begin query");
		var lat = (latitude - 1) + "," + (latitude + 1);
		var lng = (longitude - 1) + "," + (longitude + 1);

		// TODO include own sources with no location?

		$.get(makeUrl("sources"), {
			latitude : lat,
			longitude : lng
		}, function(data) {
			var src = data.sources;
			src = _.sortBy(src, function(s) {
				return (latitude - s.latitude) * (latitude - s.latitude) + (longitude - s.longitude) * (longitude - s.longitude);
			});

			if (search)
				src = _.filter(src, function(s) {
					return (s.name && s.name.indexOf(search) != -1) || (s.code && s.code.indexOf(search) != -1);
				});

			rowifyArray(src, "sources");
			success(src);
		}).error(error);
	}


	this.queryUnlocatedSources = function(createdBy, search, success, error) {
		$.get(makeUrl("sources"), {
			latitude : "null",
			created_by : createdBy
		}, function(data) {
			var src = data.sources;
			if (search)
				src = _.filter(src, function(s) {
					return (s.name && s.name.indexOf(search) != -1) || (s.code && s.code.indexOf(search) != -1);
				});
			rowifyArray(src, "sources");
			success(src);
		}).error(error);

	}


	this.querySourceByUid = function(uid, success, error) {
		$.get(makeUrl("sources/" + uid), function(data) {
			success(_.extend(data, new Row("sources")));
		}).error(error);
	}


	this.querySamplesAndTests = function(sourceUid, success, error) {
		$.get(makeUrl("sources/" + sourceUid), {
			samples : "all"
		}, function(data) {
			success(rowifyArray(data.samples, "samples"));
		}).error(error);
	};

	this.querySourceNotes = function(sourceUid, success, error) {
		$.get(makeUrl("sources/" + sourceUid + "/source_notes"), function(data) {
			success(rowifyArray(data.source_notes, "source_notes"));
		}).error(error);
	}


	this.querySourceNoteByUid = function(uid, success, error) {
		$.get(makeUrl("source_notes/" + uid), function(data) {
			success(_.extend(data, new Row("source_notes")));
		}).error(error);
	}


	this.queryTests = function(createdBy, success, error) {
		$.get(makeUrl("tests"), {
			created_by : createdBy
		}, function(data) {
			success(rowifyArray(data.tests, "tests"));
		}).error(error);
	}


	this.queryTestByUid = function(uid, success, error) {
		$.get(makeUrl("tests/" + uid), function(data) {
			success(_.extend(data, new Row("tests")));
		}).error(error);
	}

	// List of source type ids
	// TODO replace with query
	this.sourceTypes = _.range(16);
}

function MWaterSqlModel(db, syncDb) {
    var that = this;

	this.init = function(success, error) {
		db.transaction(function(tx) {
			// Create model tables
			that.createTables(tx);
			syncDb.createTables(tx);
		}, error, success);
	};
	
	// Resets all databases
	this.reset = function(success, error) {
        db.transaction(function(tx) {
            // Delete tables
            that.dropTables(tx);
            syncDb.dropTables(tx);
            
            // Create model tables
            that.createTables(tx);
            syncDb.createTables(tx);
        }, error, success);
	};
    
    // Create tables if they don't exist
    this.createTables = function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS sources( \
                      uid TEXT PRIMARY KEY DEFAULT (LOWER(HEX(RANDOMBLOB(16)))), \
                      row_version INTEGER DEFAULT 1, \
                      code TEXT, \
                      source_type INTEGER, \
                      name TEXT, \
                      desc TEXT, \
                      latitude REAL, longitude REAL, \
                      photo TEXT, \
                      created_by TEXT);");
        
        tx.executeSql("CREATE TABLE IF NOT EXISTS source_notes( \
                      uid TEXT PRIMARY KEY DEFAULT (LOWER(HEX(RANDOMBLOB(16)))), \
                      row_version INTEGER DEFAULT 1, \
                      source TEXT REFERENCES sources(uid) ON DELETE CASCADE, \
                      created_on INTEGER, \
                      operational INTEGER, \
                      note TEXT, \
                      created_by TEXT);");
        
        tx.executeSql("CREATE TABLE IF NOT EXISTS samples( \
                      uid TEXT PRIMARY KEY DEFAULT (LOWER(HEX(RANDOMBLOB(16)))), \
                      row_version INTEGER DEFAULT 1, \
                      source TEXT REFERENCES sources(uid) ON DELETE CASCADE, \
                      code TEXT, \
                      desc TEXT, \
                      sampled_on INTEGER, \
                      created_by TEXT);");
        
        tx.executeSql("CREATE TABLE IF NOT EXISTS tests( \
                      uid TEXT PRIMARY KEY DEFAULT (LOWER(HEX(RANDOMBLOB(16)))), \
                      row_version INTEGER DEFAULT 1, \
                      sample TEXT REFERENCES samples(uid) ON DELETE CASCADE, \
                      test_type INTEGER NOT NULL, \
                      test_version INTEGER, \
                      code TEXT, \
                      started_on INTEGER, \
                      read_on INTEGER, \
                      dilution INTEGER DEFAULT 1, \
                      results TEXT, \
                      notes TEXT, \
                      photo TEXT, \
                      created_by TEXT);");
    };

    this.dropTables = function (tx) {
        tx.executeSql("DROP TABLE IF EXISTS sources;");
        tx.executeSql("DROP TABLE IF EXISTS source_notes;");
        tx.executeSql("DROP TABLE IF EXISTS samples;");
        tx.executeSql("DROP TABLE IF EXISTS tests;");
    };
    
    this.transaction = function(callback, error, success) {
        db.transaction(callback, error, success);
    };
    
    this.insertRow = function(tx, table, values) {
        tx.executeSql("INSERT INTO " + table
                + " (" + _.keys(values).join()
                + ") VALUES ("
                + _.map(values, function(value, key) {
                     return "?";
                }).join()
                + ");",
                _.values(values));
        syncDb.recordInsert(tx, table, values.uid);
    };
    
    this.updateRow = function(tx, row, values) {
        tx.executeSql("UPDATE " + row.table
                + " SET "
                + _.map(values, function(value, key) {
                     return key + "=?";
                }).join()
                + " WHERE uid=?",
                _.values(values).concat([row.uid]));
        syncDb.recordUpdate(tx, row.table, row.uid);
    };

    this.deleteRow = function(tx, row) {
        tx.executeSql("DELETE FROM " + row.table + " WHERE uid=?", [row.uid]);
        syncDb.recordDelete(tx, row.table, row.uid);
    };
    
    function Row(table) {
        this.table = table;
    }
    
    // Simple query function that uses rowType as a prototype for returned rows
    var query = function(sql, params, rowType, success, error) {
        console.log("query: " + sql + "error: " + typeof error);
        db.transaction(function(tx) {
            tx.executeSql(sql, params, function(tx, results) {
                var rows=[];
                var i;
                for (i=0;i<results.rows.length;i++) {
                    var row = Object.create(rowType);
                    _.extend(row, results.rows.item(i));
                    rows.push(row);
                }
                success(rows);
            });    
        }, error);
    };
    
    var queryRowByField = function(table, field, value, rowType, success, error) {
        query("SELECT * FROM " + table + " WHERE " + field + "=?", [value], rowType, function(rows) {
            if (rows.length>0) {
                success(rows[0]);
            }
            else
                success(null);
        }, error);
    };

    this.queryNearbySources = function(latitude, longitude, search, success, error) {
    	var where = " WHERE latitude IS NOT NULL AND longitude IS NOT NULL";
        where += search ? " AND (code LIKE ? OR name LIKE ? OR desc LIKE ?)" : "";
        var sql = "SELECT * FROM sources" + where + " ORDER BY ((latitude-?)*(latitude-?)+(longitude-?)*(longitude-?))";
        var params = [latitude, latitude, longitude, longitude];
        if (search)
            params.unshift(search + "%", search + "%", search + "%");
        query(sql, params, new Row("sources"), success, error);
    };

    this.queryUnlocatedSources = function(createdBy, search, success, error) {
    	var where = " WHERE created_by = ? AND latitude IS NULL";
        where += search ? " AND (code LIKE ? OR name LIKE ? OR desc LIKE ?)" : "";
        var sql = "SELECT * FROM sources" + where + " ORDER BY uid";
        var params = [createdBy];
        if (search)
            params.push(search + "%", search + "%", search + "%");
        query(sql, params, new Row("sources"), success, error);
    };


    this.querySourceByUid = function(uid, success, error) {
        queryRowByField("sources", "uid", uid, new Row("sources"), success, error);
    };
    
    this.querySamplesAndTests = function(sourceUid, success, error) {
        query("SELECT * FROM samples WHERE source=?", [sourceUid], new Row("samples"), function(samples) {
            // Load tests for samples
            query("SELECT tests.* FROM tests INNER JOIN samples ON tests.sample=samples.uid WHERE samples.source=?",
                [sourceUid], new Row("tests"),
                function(tests) {
                    // Create empty tests list for each sample
                    _.each(samples, function(sample) { sample.tests=[]; });
                    _.each(_.groupBy(tests, function(t) { return t.sample; }),
                        function(val, key) {
                            _.find(samples, function(s) { return s.uid==key; }).tests=val;
                        });
                    success(samples);
                }, error);
      }, error);
    };

	function queryTestsGeneric(where, params, success, error) {
    	var cols = []
    	cols = cols.concat(_.map(_.where(MWaterSqlModel.tableDefs, {name:"sources"})[0].cols, function(col) { return "sources."+col+" AS sources__"+col; }));
    	cols = cols.concat(_.map(_.where(MWaterSqlModel.tableDefs, {name:"samples"})[0].cols, function(col) { return "samples."+col+" AS samples__"+col; }));
    	cols = cols.concat(_.map(_.where(MWaterSqlModel.tableDefs, {name:"tests"})[0].cols, function(col) { return "tests."+col+" AS tests__"+col; }));
        var sql = "SELECT " + cols.join() + " FROM tests \
        		LEFT OUTER JOIN samples ON tests.sample=samples.uid \
        		LEFT OUTER JOIN sources ON samples.source=sources.uid \
        		WHERE " + where + " ORDER BY tests.started_on DESC";
        
        db.transaction(function(tx) {
            tx.executeSql(sql, params, function(tx, results) {
                var rows=[]
                var i;
                for (i=0;i<results.rows.length;i++) {
                	var r = results.rows.item(i);
                    var row = Object.create(new Row("tests"));

                	row.sample = Object.create(new Row("samples"));
               		row.sample.source = Object.create(new Row("samples"));
                    
                    // Copy test values
                    _.each(r, function(value, key) {
                    	var spl = key.split("__");
                    	if (spl[0]=="tests" && spl[1] != "sample")
                    		row[spl[1]]=value;
                    	else if (spl[0]=="samples" && spl[1] != "source")
                    		row.sample[spl[1]]=value;
                    	else if  (spl[0]=="sources")
                    		row.sample.source[spl[1]]=value;
                    });
                    rows.push(row);
                }
                success(rows);
            });    
        }, error);
		
	}

    this.querySourceNotes = function(sourceUid, success, error) {
        query("SELECT * FROM source_notes WHERE source=?", [sourceUid], new Row("source_notes"), function(notes) {
        	success(notes);
        }, error);
    };
    
    this.querySourceNoteByUid = function(uid, success, error) {
        queryRowByField("source_notes", "uid", uid, new Row("source_notes"), success, error);
    };
        
    this.queryTests = function(createdBy, success, error) {
    	queryTestsGeneric("tests.created_by = ?", [createdBy], success, error);
    };

    this.queryTestByUid = function(uid, success, error) {
    	queryTestsGeneric("tests.uid = ?", [uid], function(rows) {
    		if (rows.length > 0)
    			success(rows[0]);
    		else
    			success(null);
    	}, error);
    };

    // List of source type ids
    this.sourceTypes = _.range(16); 
  }

MWaterSqlModel.tableDefs = [
    { name: "sources", cols: ["uid", "row_version", "code", "source_type", "name", "desc", "latitude", "longitude", "photo", "created_by"]},
    { name: "source_notes", cols: ["uid", "row_version", "source", "created_on", "operational", "note", "created_by"]},
    { name: "samples", cols: ["uid", "row_version", "source", "code", "desc", "sampled_on", "created_by"]},
    { name: "tests", cols: ["uid", "row_version", "sample", "test_type", "test_version", "code", "started_on", "read_on", "dilution", "results", "notes", "photo", "created_by"]},
    ];/*
 * Keeps track of markers that have been displayed on a map, determining which
 * need to be loaded, loading them, and adding them to the map.
 *
 * Also, hide/show markers as appropriate in order to optimize the speed of display.
 *
 * map: Google maps object
 *
 * geoLoadTracker: GeoLoadTracker object to store which regions have been loaded
 *
 * markerLoader: function(need, function successLoadingMarkers(rect, until, ms), function errorLoadingMarkers(error))
 * 	rect: rectagle that was loaded
 * 	until: null if fully loaded, or last uid loaded if partially loaded.
 * 	need: See GeoLoadTracker.getNeeded result.
 * 	ms: dict of markers by uid.
 */
function MapMarkerManager(map, geoLoadTracker, markerLoader) {
    var markers = {}
    var markerKeys = []
    var maxVisible = 300;
    var loading = 0;

    google.maps.event.addListener(map, 'idle', updateMarkers);

    var listeners = []
    function fireEvent(event) {
        _.each(listeners, function(e) {
            e(event);
        });
    }

    this.addListener = function(listener) {
        listeners.push(listener);
    };

    this.removeListener = function(listener) {
        listeners = _.without(listeners, listener);
    };

    // Remove all markers
    this.reset = function() {
        for ( i = 0; i < markerKeys.length; i++) {
            // Get marker
            var k = markerKeys[i];
            var m = markers[k];
            m.setMap(null);
        }
        markers = {}
        markerKeys = []
    };

    this.updateMarkers = updateMarkers;

    function extendBounds(bounds, extra) {
        var span = bounds.toSpan();

        var x1 = bounds.getSouthWest().lng();
        var y1 = bounds.getSouthWest().lat();
        var x2 = bounds.getNorthEast().lng();
        var y2 = bounds.getNorthEast().lat();

        x1 += (x1 - x2) * extra;
        y1 += (y1 - y2) * extra;
        x2 += (x2 - x1) * extra;
        y2 += (y2 - y1) * extra;

        return new google.maps.LatLngBounds(new google.maps.LatLng(y1, x1), new google.maps.LatLng(y2, x2))
    }

    function updateMarkers() {
        var bounds = map.getBounds();
        if (bounds == null)
            return;

        bounds = extendBounds(bounds, 0.2);
        var visibleCount = 0;
        var visibleUntil, i;

        for ( i = 0; i < markerKeys.length; i++) {
            // Get marker
            var k = markerKeys[i];
            var m = markers[k];

            // Determine if in bounds
            var inBounds = bounds.contains(m.getPosition());

            if (inBounds && m.getMap() == null && visibleCount < maxVisible)
                m.setMap(map);
            else if ((!inBounds || visibleCount >= maxVisible) && m.getMap() != null)
                m.setMap(null);
            if (inBounds) {
                if (visibleCount < maxVisible)
                    visibleUntil = k;
                visibleCount++;
            }
        }

        // Get needed to load
        var rect = new utils.Rect(bounds.getSouthWest().lng(), bounds.getSouthWest().lat(), bounds.getNorthEast().lng(), bounds.getNorthEast().lat());
        var needed = geoLoadTracker.getNeeded(rect);

        // If nothing to load, display completed or too_many
        if (needed.length == 0) {
            if (visibleCount > maxVisible)
                fireEvent("too_many");
            else
                fireEvent("completed");
            return;
        }

        // If needed starts *after* visibleUntil, and we're at max displayable,
        // then we already have more data than we can display
        haveEnough = _.all(needed, function(n) {
            return (visibleUntil !== undefined) && n.since != null && n.since > visibleUntil;
        });
        haveEnough &= visibleCount >= maxVisible;

        if (haveEnough) {
            fireEvent("too_many");
            return;
        }

        if (loading > 0) {
            fireEvent("loading");
            return;
        }

        _.each(needed, function(need) {
            loading++;
            markerLoader(need, successLoadingMarkers, errorLoadingMarkers);
        });
    }

    function successLoadingMarkers(rect, until, ms) {
        loading--;

        geoLoadTracker.recordLoaded(rect, until);

        // Add markers
        _.each(ms, function(value, key) {
            if (!markers[key]) {
                markers[key] = value;
            }
        });

        markerKeys = _.keys(markers).sort();

        updateMarkers()
    }

    function errorLoadingMarkers(error) {
        loading--;
    }

}
/*
 * Maintains a stack of "pages" which are similar to activities in Android. All
 * pages reside in a container when active, and are detached when not visible.
 * context: Object whose members will be inserted into each page before create is called
 * container: DOM element wrapped in jQuery where to display pages.
 * 
 * Pages can have the following members, all optional:
 * 
 * create(callback): Called when the page is created. Should put elements inside page.$el jQuery element. Must call callback when completed.
 * 
 * activate(): Called on the page comes to the forefront, either immediately after being created or when a child page is closed.
 * 
 * deactivate(): Called when the page is no longer in the front, either from being closed or from a child page opening
 * 
 * destroy(): Called when the page is closed
 * 
 * actionbarMenu: List if actionbar items. Each item must contain id (string) and title (string).
 * Optional items include icon (url) and ifRoom (boolean: determines if shown in actionbar if room)
 * 
 * actionbarTitle: string of title of page
 * 
 * actionbarMenuClick(id): Called when item is clicked.
 * 
 */
Pager = function(container, context, actionbar) {
    this.container = container;
    this.context = context;

    var that = this;
    var pressedElem;

    // Make links and anything with class 'tappable' act on taps
    container.on("mousedown touchstart", "a,button,.tappable", function(e) {
        $(this).addClass("pressed");
        pressedElem = this;
    });

    container.on("mouseup touchleave touchend touchmove touchcancel scroll", function(e) {
        if (pressedElem) {
            $(pressedElem).removeClass("pressed");
            pressedElem = null;
        }
    });

    // Make checkboxes tappable
    container.on("tap", ".checkbox", function(e) {
        $(this).toggleClass("checked");
        $(this).trigger("checked");
    });

    // Make radio buttons tappable
    container.on("tap", ".radio-button", function(e) {
        // Find parent radiogroup
        $(this).parents(".radio-group").find(".radio-button").removeClass("checked");
        $(this).addClass("checked");
        $(this).trigger("checked");
    });

    // Prevent links from launching new pages
    container.on("click", "a", function(e) {
        // Allow tabs
        if ($(e.srcElement).attr('data-toggle')=='tab')
            return true;
        return false;
    })


    this.stack = new Array();
    this.state = new Array();

    this.activatePage = function() {
        var page = _.last(this.stack);

        // Create actionbar if present
        if (actionbar) {
            actionbar.menu(page.actionbarMenu || [], function(id) {
                if (id == "home")
                    that.closePage();
                else if (page.actionbarMenuClick)
                    page.actionbarMenuClick(id);
            });

            if (page.actionbarTitle)
                actionbar.title(page.actionbarTitle);
            else
                actionbar.title(null);

            actionbar.up(this.stack.length > 1, this.stack.length > 1 ? this.stack[this.stack.length - 2].actionbarTitle : null);
        }

        if (page.activate)
            page.activate();
    };

    // Try to load from pages global
    this.onLoad = function(name, success, error) {
        if (pages && pages[name])
            success(pages[name]);
        else
            error();
    };

    // Loads a page on top of existing pages. Pass name and args array
    // to create it. Default action is to look in global "pages"
    // for constructor with name
    this.loadPage = function(name, args, callback, onlyCreate) {
        console.log("Pager.loadPage(" + name + ", " + JSON.stringify(args) + ")");

        // Create page
        this.onLoad(name, function(constructor) {
            if (!onlyCreate) {
                // Hide current page
                if (that.stack.length > 0) {
                    if (_.last(that.stack).deactivate)
                        _.last(that.stack).deactivate();
                    _.last(that.stack).$el.detach();
                }
            }

            // Call constructor
            var page = Object.create(constructor.prototype);
            constructor.apply(page, args);

            // Set pager and context
            page.pager = that;
            _.extend(page, context);

            // Add new page
            that.stack.push(page);
            that.state.push({
                name : name,
                args : args
            });
            that.onStateChanged(that.state);

            function activatePage() {
                that.container.html('');
                that.container.append(page.$el);

                // Scroll to top
                container.parent().scrollTop(0)

                that.activatePage(page);
            }

            // Create page element and convenience selector
            page.$el = $('<div id="page"></div>');
            page.$ = function(sel) {
                return page.$el.find(sel);
            };

            // Create page
            if (page.create)
                page.create(function() {
                    if (!onlyCreate)
                        activatePage();
                    if (callback)
                        callback(page);
                });
            else {
                if (!onlyCreate)
                    activatePage();
                if (callback)
                    callback(page);
            }
        }, function(error) {
            console.error("Unable to load page. " + JSON.stringify(error));
            alert("Unable to load page. " + error);
        });
    };

    /* Closes the top page, optionally replacing it with another page */
    this.closePage = function(replaceWith, args) {
        // Ignore if no pages would be left
        if (!replaceWith && this.stack.length <= 1)
            return;

        // If at least one page to close
        if (this.stack.length > 0) {
            var page = this.stack.pop();
            this.state.pop();
            this.onStateChanged(that.state);

            // Deactivate current page and destroy
            if (page.deactivate)
                page.deactivate();
            if (page.destroy)
                page.destroy();

            page.$el.remove();
        }

        if (replaceWith)
            this.loadPage(replaceWith, args);
        else if (this.stack.length > 0) {
            // Activate current page
            this.container.append(_.last(this.stack).$el);
            this.activatePage();
        }
    };

    // Sets the state
    this.setState = function(newstate) {
        // Create each page before last
        if (newstate.length > 1) {
            // Create page, but do not attach
            this.loadPage(_.first(newstate).name, _.first(newstate).args, function() {
                that.setState(_.rest(newstate));
            }, true);
        } else if (newstate.length > 0)
            this.loadPage(newstate[0].name, newstate[0].args);
    };


    this.onStateChanged = function(state) {
    };
};

// Makes rows of a table tappable
Pager.makeTappable = function(table, ontap) {
    table.on("tap", "tr", function(e) {
        ontap(this)
    });

    var pressedElem;

    table.on("mousedown touchstart", "tr", function(e) {
        $(this).addClass("pressed");
        pressedElem = this;
    });

    table.on("mouseup touchleave touchend touchmove touchcancel mousemove scroll", function(e) {
        if (pressedElem) {
            $(pressedElem).removeClass("pressed");
            _.delay(function() {
                $(pressedElem).removeClass("pressed");
                pressedElem = null;
            }, 100);
        }
    });
};

// Makes a table searchable with a searchbar
Pager.makeSearchable = function(table, searchbar) {
    searchbar.on("input change", function(ev) {
        var q = this.value;
        table.find("tr").each(function(i) {
            src = sources[i]
            if (src.name.toLowerCase().indexOf(q.toLowerCase()) == -1)
                $(this).hide();
            else
                $(this).show();
        });
    });
};
/* Handles displaying a photo in a thumbnail and respond to taps on it.
 * element: image element wrapped in jquery
 * imageManager: ImageManager
 * model: MWater model
 * row: row containing "photo" field
 * error: called when error has occurred */
function PhotoDisplayer(page, element, row, error) {
	function takePicture() {
		if (!navigator.camera) {
			alert("Camera not available");
			return;
		}

		function pictureFail() {
			console.error("Failed to take picture");
			alert("Failed to take picture");
		}

		function pictureSucceed(uri) {
			console.log("Succeeded to take picture");

			var photoUid = utils.createUid();

			// Add to image manager
			page.imageManager.addImage(uri, photoUid, function() {
				// Set in row
				page.model.transaction(function(tx) {
					page.model.updateRow(tx, row, {
						photo : photoUid
					});
				}, error, function() {
					row.photo = photoUid;
					displayPhoto();
				});
			}, error);
		}

		// Start get picture
		console.log("About to take picture");
		navigator.camera.getPicture(pictureSucceed, pictureFail, {
			quality : 50,
			destinationType : Camera.DestinationType.FILE_URI,
		});
	}

    var photoOk = true; // Set to false if photo failed to load

	function displayPhoto() {
		// Load image
		if (row.photo) {
			page.imageManager.getImageThumbnailUrl(row.photo, function(url) {
				element.attr("src", url);
				photoOk = true;
			}, function() {
				element.attr("src", "images/no-image-icon.jpg");
				photoOk = false;
			});
		}
		else {
			element.attr("src", "images/camera-icon.jpg");
		}
	}

	// Load image
	displayPhoto();

	// Listen for clicks to take photo
	element.on("tap", function() {
		if (row.photo && photoOk)
			page.pager.loadPage("Photo", [row.photo]);
		else
			takePicture();
	});
}
function ProblemReporter(baseUrl, version, getClientUid) {
    var history = [];
    var that = this;

    // IE9 hack
    if (Function.prototype.bind && console && typeof console.log == "object") {
        [
          "log","info","warn","error","assert","dir","clear","profile","profileEnd"
        ].forEach(function (method) {
            console[method] = this.bind(console[method], console);
        }, Function.prototype.call);
    }

    function capture(func) {
        var old = console[func];
        console[func] = function(arg) {
            history.push(arg);
            if (history.length > 200)
                history.splice(0, 20);
            old.call(console, arg);
        }

    }

    capture("log");
    capture("warn");
    capture("error");

    function getLog() {
        var log = "";
        _.each(history, function(item) {
            log += String(item) + "\r\n";
        });
        return log;
    }


    this.reportProblem = function(desc) {
        // Create log string
        var log = getLog();

        console.log("Reporting problem...");

        $.post(baseUrl + "problem_reports", {
            clientuid : getClientUid(),
            version : version,
            user_agent : navigator.userAgent,
            log : log,
            desc : desc
        });
    };

    // Capture error logs
    var debouncedReportProblem = _.debounce(this.reportProblem, 5000, true);

    var oldConsoleError = console.error;
    console.error = function(arg) {
        oldConsoleError(arg);

        debouncedReportProblem(arg);
    };

    // Capture window.onerror
    var oldWindowOnError = window.onerror;
    window.onerror = function(errorMsg, url, lineNumber) {
        that.reportProblem("window.onerror:" + errorMsg + ":" + url + ":" + lineNumber);
        
        // Put up alert instead of old action
        alert("Internal Error\n" + errorMsg + "\n" + url + ":" + lineNumber);
        //if (oldWindowOnError)
        //    oldWindowOnError(errorMsg, url, lineNumber);
    };
}

ProblemReporter.register = function(baseUrl, version, getClientUid) {
    if (!ProblemReporter.instances)
        ProblemReporter.instances = {}

    if (ProblemReporter.instances[baseUrl])
        return;

    new ProblemReporter(baseUrl, version, getClientUid);
}
/* Obtains source codes from the server and manages a local store of them */

function SourceCodeManager(syncServer) {

    // Gets list of cached source codes in form { code:<code>, expiry:<expiry in s since epoch> }
    function getLocalCodes() {
        if (!localStorage.getItem("sourceCodes"))
            return [];
        return JSON.parse(localStorage.getItem("sourceCodes"));
    }

    // Sets list of cached source codes in form { code:<code>, expiry:<expiry in s since epoch> }
    function setLocalCodes(codes) {
        localStorage.setItem("sourceCodes", JSON.stringify(codes));
    }

    // Purge expired code
    function purgeCodes(cutoff) {
        setLocalCodes(_.reject(getLocalCodes(), function(item) {
            return item.expiry < cutoff;
        }));
    }

    // Replenish codes from server to have a minimum of x available
    this.replenishCodes = function(minNumber, success, error, now) {
        var now = now || (new Date()).getTime() / 1000;

        // Purge old codes
        purgeCodes(now);

        // Determine how many are needed
        var numNeeded = minNumber - getLocalCodes().length;

        // If have enough
        if (numNeeded <= 0) {
            success();
            return;
        }

        // Request new codes
        syncServer.requestSourceCodes(numNeeded, function(codes, expiry) {
            // Add to local storage, halfing expiry time to be safe
            var newitems = _.map(codes, function(code) {
                return {
                    code : code,
                    expiry : (expiry - now) / 2 + now
                };
            });

            setLocalCodes(getLocalCodes().concat(newitems));
            success();
        }, error);
    };

    this.getNumberAvailableCodes = function(now) {
        now = now || (new Date()).getTime() / 1000;
        purgeCodes(now);

        return getLocalCodes().length;
    };

    this.requestCode = function(success, error, now) {
        // Replenish codes to have at least one
        this.replenishCodes(1, function() {
            var codes = getLocalCodes();

            // Remove first code
            setLocalCodes(_.rest(codes));
            success(_.first(codes).code);
        }, error, now);
    };

    // Reset all codes cached
    this.reset = function() {
        setLocalCodes([]);
    }

}
/* Sets up a map to display sources */
function SourceMap(elem, apiUrl, mapOptions, sourceClick) {
	var that = this;

    // Requery to get any new markers
    this.updateMarkers = function() {
		this.geoLoadTracker.reset();
		this.mapMarkerManager.reset();
        this.mapMarkerManager.updateMarkers();
	};
	
	this.displayStatus = function(status) {
		if (status)
			$("#status_control").text(status).show();
		else
			$("#status_control").hide();
	};

	this.createMarker = function(source) {
		var color;
		// Determine color
		if (source.samples.length > 0) {
			color = "#D0D0D0";
			var anl = sampleanalysis.getAnalyses(_.last(source.samples));
			if (anl.length > 0)
				color = anl[0].color;
		} else
			color = "#D0D0D0";

		icon = {
			path : google.maps.SymbolPath.CIRCLE,
			fillColor : color,
			fillOpacity : 1,
			scale : 6,
			strokeColor : "black",
			strokeWeight : 2
		};

		var marker = new google.maps.Marker({
			position : new google.maps.LatLng(source.latitude, source.longitude),
			icon : icon
		});

		google.maps.event.addListener(marker, 'click', function() {
			sourceClick(source, marker);
		});

		return marker;
	};


	function markerLoader(need, success, error) {
		var max = 100;

		// Query api
		var params = {
			limit : max,
			latitude : need.rect.y1 + "," + need.rect.y2,
			longitude : need.rect.x1 + "," + need.rect.x2,
			samples : 1
		};

		if (need.since)
			params.uid_gt = need.since;

		// Query server for sources
		$.get(apiUrl + "sources", params).success(function(data) {
			var sources = data.sources;

			// Make into marker
			var dict = {}
			_.each(sources, function(s) {
				dict[s.uid] = that.createMarker(s);
			});

			// Determine if completely loaded
			var until;
			if (sources.length >= max)
				until = _.last(sources).uid;
			else
				until = null;

			success(need.rect, until, dict);
		}).error(function() {
			alert("Error getting data");
		});
	}

	function addMarkers() {
		// Add info control
		that.gmap.controls[google.maps.ControlPosition.TOP_CENTER].push($('<div id="status_control" style="display:none;"></div>').get(0));

		that.geoLoadTracker = new GeoLoadTracker();
		that.mapMarkerManager = new MapMarkerManager(that.gmap, that.geoLoadTracker, markerLoader);
		that.mapMarkerManager.addListener(function(event) {
			if (event == "completed")
				that.displayStatus();
			else if (event == "too_many")
				that.displayStatus("Zoom in to see more");
			else if (event == "loading")
				that.displayStatus("Loading...");
		});
	}

	if (!mapOptions) {
		mapOptions = {
			zoom : 11,
			center : new google.maps.LatLng(-2.55, 32.95),
			mapTypeId : google.maps.MapTypeId.ROADMAP
		};
	}

	this.gmap = new google.maps.Map(elem, mapOptions);
	addMarkers();
}
/* Responsible for synchronizing a SyncDb-enabled database with a server
 * Synchronization is always done by first uploading and then downloading
 * any changes to be applied. All uploads must be completed before any downloads
 * can be applied.
 */

/* syncDb: SyncDb to use
 * syncServer: object with two functions
 * uploadChanges(changes, success(), error())
 * downloadChanges(sliceMap, success(changes), error())
 *
 * sliceMap is map from slice id to "until" value. Determines what to download: everthing after "until"
 */
function SyncClient(syncDb, syncServer) {
    this.syncDb = syncDb;
    this.syncServer = syncServer;
}

/* Synchronize for a client with the specified slices */
SyncClient.prototype.sync = function(slices, success, error) {
    var that = this;

    // First upload changes
    this.upload(function(changes) {
        // Upload completed, record success
        that.syncDb.clearPendingChanges(changes, function() {
            that.download(slices, success, error);
        }, error);
    }, error);
};

/* Downloads any changes. Calls success with parameters:
 * changes: changes that were received. null for none */
SyncClient.prototype.download = function(slices, success, error) {
    var that = this;
 
    // Start download after determining slices needed
    that.syncDb.getSliceUntils(slices, function(sliceMap) {
        that.syncServer.downloadChanges(sliceMap, function(changes) {
            // Now have changes data, apply
            that.applyChanges(changes, slices, success, error);
        }, error);
    }, error);
};

/* Uploads any local changes. Calls success with parameters:
 * changes: changes that were uploaded, or null if none */
SyncClient.prototype.upload = function(success, error) {
    var that = this;
    this.syncDb.getPendingChanges(function(changes) {
        // Check if upload needed
        if (changes != null) {
            that.syncServer.uploadChanges(changes, function() {
                if (success)
                    success(changes);
            }, error);
        }
        else {
            if (success)
                success(null);
        }
    }, error);
};

/* Applies changes that have been downloaded */
SyncClient.prototype.applyChanges = function(downloadedChanges, slices, success, error) {
    var that = this;

    // Apply changes, but first call upload and see if upload was needed
    this.upload(function(uploadedChanges) {
        // If upload was needed, try applying changes again, as more
        // may have accumulated
        if (uploadedChanges)
            that.applyChanges(downloadedChanges, slices, success, error);
        else {
            // Apply changes to syncDb
            that.syncDb.applyChanges(downloadedChanges, slices, error, success);
        }
    }, error);
};/* Sets up a database for synchronization. Synchronization involves manually recording
 * inserts, updates and deletes in a special table "syncchanges".
 *
 * From this, a change set of upserts and deletes for all tables can be created.
 *
 * Also records which data slices have been downloaded from the server in the table "dataslices".
 *
 */

/* Create SyncDb.
 * db: database
 * tableDefs: array of table definition, each with "name" and a "cols" array of column names, in topological order
 */
function SyncDb(db, tableDefs) {
    this.db = db;
    this.tableDefs = tableDefs;
}

// Creates all of the tables needed if they do not exist
SyncDb.prototype.createTables = function(tx) {
    tx.executeSql("CREATE TABLE IF NOT EXISTS syncchanges ( \
                  id INTEGER PRIMARY KEY AUTOINCREMENT, \
                  tablename TEXT NOT NULL, \
                  rowuid TEXT NOT NULL, \
                  action TEXT NOT NULL);");
    
    tx.executeSql("CREATE TABLE IF NOT EXISTS dataslices ( \
                  id TEXT PRIMARY KEY, \
                  serveruntil INTEGER NOT NULL);");
};

// Drops all tables if they exist
SyncDb.prototype.dropTables = function(tx) {
    tx.executeSql("DROP TABLE IF EXISTS syncchanges;");
    tx.executeSql("DROP TABLE IF EXISTS dataslices;");
};

// Records that an insert was done on a specific table of a row with the specified uid
SyncDb.prototype.recordInsert = function(tx, table, uid) {
    tx.executeSql("INSERT INTO syncchanges (tablename, rowuid, action) VALUES (?, ?, ?);",
                  [table, uid, 'I']);
};

// Records that an update was done on a specific table of a row with the specified uid
SyncDb.prototype.recordUpdate = function(tx, table, uid) {
    tx.executeSql("INSERT INTO syncchanges (tablename, rowuid, action) VALUES (?, ?, ?);",
                  [table, uid, 'U']);
};

// Records that an delete was done on a specific table of a row with the specified uid
SyncDb.prototype.recordDelete = function(tx, table, uid) {
    tx.executeSql("INSERT INTO syncchanges (tablename, rowuid, action) VALUES (?, ?, ?);",
                  [table, uid, 'D']);
};

/* Gets object of changes pending. Structure is:
 * tables: list of tables
 * until: up to when (id in syncchanges) are changes recorded for
 *
 * table: name (name of table)
 * upserts: cols and rows to upsert
 * deletes: uid of rows to delete
 */
SyncDb.prototype.getPendingChanges = function(success, error) {
    var that = this;
    
    // Convenience function to fill an array
    function newFilledArray(length, val) {
        var array = [], i;
        for (i = 0; i < length; i++) {
            array[i] = val;
        }
        return array;
    }
    
    // Converts sql results to a list
    function resultsToList(results) {
        var rows = [], i;
        for (i=0;i<results.rows.length;i++)
            rows.push(results.rows.item(i));
        return rows;
    }

	function gatherUpserts(tx, cstable, upserts) {
        // Get tableDef
        var tableDef = _.find(that.tableDefs, function(td) { return td.name==cstable.name; });

	    // Gather upserts
	    tx.executeSql("SELECT * FROM " + cstable.name + " WHERE uid in ("
	        + newFilledArray(upserts.length, "?")
	        + ");",
	        upserts,
	        function(tx, results) {
	            var rows = resultsToList(results);
	            if (rows.length > 0)
	            {
	                // Record upserts, ignoring ignored columns
	                cstable.upserts = { cols: _.keys(_.pick(rows[0], tableDef.cols)), rows: [] }
	                _.each(rows, function(row) {
	                    cstable.upserts.rows.push(_.values(_.pick(row, tableDef.cols)));
	                });
	            }
	        });
	}

    // Processes the list of changes
    function processChanges(tx, results) {
        // Group by table
        var grps = _.groupBy(resultsToList(results), 'tablename');

        // Create changes
        var cs = { tables: []}

        // Begin transaction
        that.db.transaction(function(tx) {
            // Set until
            tx.executeSql("SELECT MAX(id) AS until FROM syncchanges", [], function(tx, results) {
                cs.until = results.rows.item(0).until || 0;
            });
            
            // For each table
            var tbl;
            for (tbl in grps) {
                // Get tableDef
                var tableDef = _.find(that.tableDefs, function(td) { return td.name==tbl; });
                
                var cstable = { name: tbl };
                cs.tables.push(cstable);
                
                // Get inserts updates deletes
                var inserts = _.pluck(_.where(grps[tbl], { action: "I"}), "rowuid");
                var updates = _.pluck(_.where(grps[tbl], { action: "U"}), "rowuid");
                var deletes = _.pluck(_.where(grps[tbl], { action: "D"}), "rowuid");
                
                // Record deletes
                if (deletes.length>0)
                    cstable.deletes = deletes;
                
                // Upserts are inserts/updates without deletes
                var upserts = _.difference(_.union(inserts, updates), deletes);
                gatherUpserts(tx, cstable, upserts);
			}
        }, error, function() {
            success(cs.tables.length>0 ? cs : null);
        });
    }
    
    this.db.transaction(function(tx) {
        tx.executeSql("SELECT * FROM syncchanges ORDER BY tablename, action, rowuid", [], processChanges);
    }, error);
};

/* Clears pending changes that are contained in changes. If changes null, do nothing */
SyncDb.prototype.clearPendingChanges = function(changes, success, error) {
    if (changes != null) {
        this.db.transaction(function(tx) {
            tx.executeSql("DELETE FROM syncchanges WHERE id<=?", [changes.until]);
        }, error, success);
    }
    else
        success();
};

/* Determines the "until" value of data slices stored. If no data for a
 * slice has ever been received, is zero.
 * success is called with keys of slices, and values of untils */
SyncDb.prototype.getSliceUntils = function(slices, success, error) {
    this.db.transaction(function(tx) {
        tx.executeSql("SELECT * FROM dataslices WHERE id IN ("
            + _.map(slices, function() { return "?"}).join()+ ");", slices,
            function(tx, results) {
                var output = {}, i;
                // Set slices to 0 initially
                _.each(slices, function(slice) { output[slice]=0; });
                for (i=0;i<results.rows.length;i++)
                    output[results.rows.item(i).id] = results.rows.item(i).serveruntil;
                success(output);
            }, error);
    });
};

/* Applies changes from the server for the specified slices */
SyncDb.prototype.applyChanges = function(changes, slices, error, success) {
    var that = this;
    
    if (!changes)
    {
        success();
        return;
    }

    function performUpserts(tx, tableDef, upserts) {
        _.each(upserts.rows, function(row) {
            // Make into key value set
            var rowobj = _.object(upserts.cols, row);
            
            // Remove unknown columns
            rowobj = _.pick(rowobj, tableDef.cols)
            
            // Make ?, ?, etc. string
            var params = _.map(rowobj, function() { return "?"}).join()
            
            // Perform upsert
            tx.executeSql("UPDATE " + tableDef.name
                + " SET "
                + _.map(rowobj, function(value, key) {
                     return key + "=?";
                }).join()
                + " WHERE uid=?",
                _.values(rowobj).concat([rowobj.uid]),
                function(tx, results) {
                    if (results.rowsAffected == 0) {
                        tx.executeSql("INSERT INTO " + tableDef.name
                            + "(" + _.keys(rowobj).join() + ")"
                            + " VALUES ("
                            + params
                            + ");", _.values(rowobj));
                    }
                });
        });
    }
    
    function performDeletes(tx, tableDef, deletes) {
        _.each(deletes, function(uid) {
            // Perform delete
            tx.executeSql("DELETE FROM " + tableDef.name + " WHERE uid=?", [uid]);
        });
    }
    
    this.db.transaction(function (tx) {
        // Record slices
        _.each(slices, function(slice) {
            tx.executeSql("INSERT OR REPLACE INTO dataslices (id, serveruntil) VALUES (?,?);",
                [slice, changes.until]);
        });
        
        // For each table
        _.each(changes.tables, function(table) {
            // Get tableDef, and ignore if unknown
            var tableDef = _.find(that.tableDefs, function(td) { return td.name==table.name; });
            if (!tableDef)
                return;
            
            // For each upsert
            if (table.upserts)
                performUpserts(tx, tableDef, table.upserts);
            
            // For each delete
            if (table.deletes)
                performDeletes(tx, tableDef, table.deletes);
        });
    }, error, success);
}
/* Responsible for connecting to a sync server. Persists login information in localstorage */

// baseUrl: api url, ending in "/"
function SyncServer(baseUrl) {
    var that = this;

    this.baseUrl = baseUrl;

    this.manualLogin = function(username, clientUid) {
        localStorage.setItem("username", username);
        localStorage.setItem("clientUid", clientUid);
    };

    this.signup = function(email, username, password, success, error) {
        $.ajax(baseUrl + "users/" + username, {
            type : "PUT",
            data : {
                email : email,
                password : password
            }
        }).success(function(data) {
            that.manualLogin(username, data.clientuid);
            success();
        }).error(error);
    };

    this.login = function(username, password, success, error) {
        $.post(baseUrl + "users/" + username, {
            password : password
        }).success(function(data) {
            that.manualLogin(username, data.clientuid);
            success();
        }).error(error);
    };

    this.logout = function(success, error) {
        $.ajax(baseUrl + "clients/" + that.getClientUid(), {
            type : "DELETE",
            success : success,
            error : error
        });
        that.manualLogin("", "");
    };


    this.getUsername = function() {
        return localStorage.getItem("username");
    };


    this.getClientUid = function() {
        return localStorage.getItem("clientUid");
    };

    this.loggedIn = function() {
        return this.getClientUid() != null && this.getClientUid() != "";
    };

}

SyncServer.prototype.uploadChanges = function(changes, success, error) {
    $.post(this.baseUrl + "sync", {
        clientuid : this.getClientUid(),
        changeset : JSON.stringify(changes)
    }).success(success).error(error);
};

SyncServer.prototype.downloadChanges = function(sliceMap, success, error) {
    $.get(this.baseUrl + "sync", {
        clientuid : this.getClientUid(),
        slices : JSON.stringify(sliceMap)
    }).success(function(data) {
        success(data);
    }).error(error);
};

SyncServer.prototype.getImageThumbnailUrl = function(imageUid) {
    return this.baseUrl + "images/" + imageUid + "/thumbnail";
};

SyncServer.prototype.getImageUrl = function(imageUid) {
    return this.baseUrl + "images/" + imageUid;
};

SyncServer.prototype.requestSourceCodes = function(number, success, error) {
    $.post(this.baseUrl + "source_codes", {
        clientuid : this.getClientUid(),
        number : number
    }).success(function(data) {
        success(data.codes, data.expire_on);
    }).error(error);
};

// Gets welcome message. success is called with (valid, message, fatal)
SyncServer.prototype.getWelcome = function(version, success, error) {
    $.get(this.baseUrl + "welcome/" + this.getClientUid(), {
        version : version
    }, function(data) {
        success(true, data.message, data.fatal);
    }).error(function(jqXHR, textStatus, errorThrown) {
        if (jqXHR.status == 403) {
            success(false, "", false);
        } else if (error)
            error(errorThrown);
    });
};

/*
   Copyright 2012 Wolfgang Koller - http://www.gofg.at/

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

cordova.define("cordova/plugin/bluetooth", function(require, exports, module) {
    var exec = require('cordova/exec');
    
    var Bluetooth = function() {};
    
    /**
     * Check if bluetooth API is supported on this platform
     * @returns true if bluetooth API is supported, false otherwise
     */
    Bluetooth.prototype.isSupported = function() {
        // Currently only supported on android
        if( device.platform.toLowerCase() == "android" ) return true;
        
        return false;
    };
    
    /**
     * Enable bluetooth
     * 
     * @param successCallback function to be called when enabling of bluetooth was successfull
     * @param errorCallback function to be called when enabling was not possible / did fail
     */
    Bluetooth.prototype.enable = function(successCallback,failureCallback) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'enable', []);
    };
    
    /**
     * Disable bluetooth
     * 
     * @param successCallback function to be called when disabling of bluetooth was successfull
     * @param errorCallback function to be called when disabling was not possible / did fail
     */
    Bluetooth.prototype.disable = function(successCallback,failureCallback) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'disable', []);
    };
    
    /**
     * Search for devices  and list them
     * 
     * @param successCallback function to be called when discovery of other devices has finished. Passed parameter is a JSONArray containing JSONObjects with 'name' and 'address' property.
     * @param errorCallback function to be called when there was a problem while discovering devices
     */
    Bluetooth.prototype.discoverDevices = function(successCallback,failureCallback) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'discoverDevices', []);
    };
    
    /**
     * List paired devices
     * 
     * @param successCallback function to be called when listing of paired devices has finished. Passed parameter is a JSONArray containing JSONObjects with 'name' and 'address' property.
     * @param errorCallback function to be called when there was a problem while discovering devices
     */
    Bluetooth.prototype.getPaired = function(successCallback,failureCallback) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'getPaired', []);
    };
    
    /**
     * Return list of available UUIDs for a given device
     * 
     * @param successCallback function to be called when listing of UUIDs has finished. Passed parameter is a JSONArray containing strings which represent the UUIDs
     * @param errorCallback function to be called when there was a problem while listing UUIDs
     */
    Bluetooth.prototype.getUUIDs = function(successCallback,failureCallback,address) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'getUUIDs', [address]);
    };
    
    /**
     * Open an RFComm channel for a given device & uuid endpoint
     * 
     * @param successCallback function to be called when the connection was successfull. Passed parameter is an integer containing the socket id for the connection
     * @param errorCallback function to be called when there was a problem while opening the connection
     */
    Bluetooth.prototype.connect = function(successCallback,failureCallback,address,uuid) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'connect', [address, uuid]);
    };
    
    /**
     * Close a RFComm channel for a given socket-id
     * 
     * @param successCallback function to be called when the connection was closed successfully
     * @param errorCallback function to be called when there was a problem while closing the connection
     */
    Bluetooth.prototype.disconnect = function(successCallback,failureCallback,socketid) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'disconnect', [socketid]);
    };
    
    /**
     * Read from a connected socket
     * 
     * @param successCallback function to be called when reading was successfull. Passed parameter is a string containing the read content
     * @param errorCallback function to be called when there was a problem while reading
     */
    Bluetooth.prototype.read = function(successCallback,failureCallback,socketid) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'read', [socketid]);
    };

    /**
     * Write to a connected socket
     * 
     * @param successCallback function to be called when writing was successfull. 
     * @param errorCallback function to be called when there was a problem while writing
     */
    Bluetooth.prototype.write = function(successCallback,failureCallback,socketid,text) {
        return exec(successCallback, failureCallback, 'BluetoothPlugin', 'write', [socketid,text]);
    };
    
    var bluetooth = new Bluetooth();
    module.exports = bluetooth;
});
var geoslicing = geoslicing || {};

(function() {
	// Get slice ids for a location, with slice size of size
	geoslicing.getSlices = function(size, lat, lng) {
		var slices = []

		function wrapLat(x) {
			return ((x + 90 + 360) % 180) - 90;
		}

		function wrapLng(x) {
			return ((x + 180 + 360) % 360) - 180;
		}

		// Round lat and lng
		lat = Math.round(lat / size) * size;
		lng = Math.round(lng / size) * size;

		// Create 4 regions
		var rects = []
		rects.push([wrapLat(lat - size), wrapLat(lat), wrapLng(lng - size), wrapLng(lng)])
		rects.push([wrapLat(lat), wrapLat(lat + size), wrapLng(lng - size), wrapLng(lng)])
		rects.push([wrapLat(lat - size), wrapLat(lat), wrapLng(lng), wrapLng(lng + size)])
		rects.push([wrapLat(lat), wrapLat(lat + size), wrapLng(lng), wrapLng(lng + size)])

		return _.map(rects, function(r) {
			return "source.rect:"+r.join();
		});
	};

})();
i18n = {
	localizeField: function(field, value) {
		var key = field + "." + value;
		if (this[key])
			return i18n[key];
		return key;
	},
	"sources.source_type.0" : "Piped into dwelling",
	"sources.source_type.1" : "Piped into yard/plot",
	"sources.source_type.2" : "Public tap or standpipe",
	"sources.source_type.3" : "Tubewell",
	"sources.source_type.4" : "Borehole",
	"sources.source_type.5" : "Protected dug well",
	"sources.source_type.6" : "Protected spring",
	"sources.source_type.7" : "Rainwater catchment",
	"sources.source_type.8" : "Unprotected spring",
	"sources.source_type.9" : "Unprotected dug well",
	"sources.source_type.10" : "Cart with tank",
	"sources.source_type.11" : "Tanker-truck",
	"sources.source_type.12" : "Surface Water",
	"sources.source_type.13" : "Bottled Water",
	"sources.source_type.14" : "Public tank or basin",
	"sources.source_type.15" : "Supply network sampling point",
	
	"tests.test_type.0" : "Petrifilm E. coli",
	"tests.test_type.1" : "10mL Colilert",
	"tests.test_type.2" : "100mL E. coli",
	"tests.test_type.3" : "UNC Compartmentalized Bag",
	"tests.test_type.4" : "Chlorine",
	"tests.test_type.5" : "General Microbiology",
	
	"tests.test_type.5.type.ecoli" : "E. coli",
	"tests.test_type.5.type.total_coliforms" : "Total Coliforms",
	"tests.test_type.5.type.thermotolerant_coliforms" : "Thermotolerant Coliforms",
	"tests.test_type.5.type.enterococci" : "Enterococci",
	"tests.test_type.5.type.heterotrophic_plate_count" : "Heterotrophic Plate Count",
	"tests.test_type.5.type.faecal_streptococci" : "Faecal streptococci",
	"tests.test_type.5.type.clostridium_perfringens" : "Clostridium perfringens",
	
	"source_notes.operational.null" : "Unknown",
	"source_notes.operational.0" : "Broken",
	"source_notes.operational.1" : "Working",
	"source_notes.operational.false" : "Broken",
	"source_notes.operational.true" : "Working",
}

sampleanalysis = {};
(function() {
	sampleanalysis.getAnalyses = function(sample) {
		analyses = []
		anl = sampleanalysis.getEcoliAnalysis(sample);
		if (anl != null)
			analyses.push(anl);
		return analyses;
	};

	sampleanalysis.getEcoliAnalysis = function(sample) {
		// Analyse E.Coli
		var emin = null
		var emax = null
		_.each(sample.tests, function(test) {
			range = getEcoliRange(test);
			if (emin == null || (range.min && range.min > emin))
				emin = range.min;
			if (emax == null || (range.max && range.max < emax))
				emax = range.max;
		});
		// If min or max found, record analysis
		if (emin || emax) {
			anl = {
				name : "E.Coli",
				namestyle : "font-style:italic;"
			}

			var uncertain = false;
			if (emin && emax && emax < emin + 1) {
				emax = emin + 1;
				uncertain = true;
			}

			anl.color = getEcoliColor(emax);
			anl.risk = getEcoliRisk(emax);

			if (emin && emax) {
				if (uncertain)
					anl.text = emin + " CFU/100ml";
				else if (emax == emin + 1)
					anl.text = emin + " CFU/100ml";
				else
					anl.text = emin + "-" + (emax - 1) + " CFU/100ml";
			} else if (emax)
				anl.text = "<" + emax + " CFU/100ml";
			else if (emin)
				anl.text = ">=" + emin + " CFU/100ml";
			return anl;
		}
		return null;
	};


	/* Summarizes into summary and color */
	sampleanalysis.summarizeTest = function(test) {
		if (!test.results) {
			return {
				text : "Pending"
			};
		}

		var results = $.parseJSON(test.results)
		
		// Create sample to analyse
		var sample = {
			tests : [test]
		}
		var anl = sampleanalysis.getEcoliAnalysis(sample);

		
		if (test.test_type == 4) // Chlorine
		{
			if (results.present)
				return {
					text : "Positive",
					color : "Green"
				};
			else
				return {
					text : "Negative",
					color : "Red"
				};
		}

		if (test.test_type == 5) // General
		{
			return {
				text: i18n.localizeField("tests.test_type.5.type", results.type) + ": " + results.value + "/100mL",
				color: anl ? anl.color : null
			}
		}

		if (!anl)
			return {
				text : ""
			};
		else
			return {
				text : anl.text,
				color : anl.color
			};
	}

	function getEcoliRisk(level) {
		if (level == null)
			return 0;
		if (level <= 1)
			return 1;
		if (level <= 10)
			return 2;
		if (level <= 100)
			return 3;
		if (level <= 1000)
			return 4;
		return 5;
	}

	function getEcoliRange(test) {
		// Gets range of ecoli results (>=min, <max)
		if (!test.results)
			return {
				min : null,
				max : null
			};

		var results = $.parseJSON(test.results)
		var ecoli = 0
		if (test.test_type == 0) {// Petrifilm
			ecoli = null
			if (results.autoEcoli)
				ecoli = results.autoEcoli;
			if (results.manualEcoli)
				ecoli = results.manualEcoli;
			if (ecoli == null)
				return {
					min : null,
					max : null
				};
			return {
				min : ecoli * test.dilution * 100,
				max : ((ecoli + 1) * test.dilution * 100)
			};
		}
		if (test.test_type == 1) {// 10ml Colilert
			if (results.ecoli == true)
				return {
					min : test.dilution * 10,
					max : null
				};
			if (results.ecoli == false)
				return {
					min : null,
					max : test.dilution * 10
				};
			return {
				min : null,
				max : null
			};
		}
		if (test.test_type == 2) {// 100ml Colilert
			if (results.ecoli == true)
				return {
					min : test.dilution,
					max : null
				};
			if (results.ecoli == false)
				return {
					min : null,
					max : test.dilution
				};
			return {
				min : null,
				max : null
			};
		}
		if (test.test_type == 5) {// General microbiology
			if (results.type == "ecoli")
				return {
					min : test.dilution * results.value,
					max : test.dilution * results.value
				};
		}

		return {
			min : null,
			max : null
		};
	}

	function getEcoliColor(level) {
		if (level == null)
			return "#FF4040";
		if (level <= 1)
			return "#62B9FC";
		if (level <= 10)
			return "#40FF40";
		if (level <= 100)
			return "#FFFF40";
		if (level <= 1000)
			return "#FFA040";
		return "#FF4040";
	}

})();
var surveys = surveys || {} 

surveys.SurveyModel = Backbone.Model.extend({

});

surveys.SurveyView = Backbone.View.extend({
    className : "survey",
    template : _.template('<h2><%=title%></h2><ul class="breadcrumb"></ul><div class="sections"></div>' + '<button type="button" class="btn prev"><i class="icon-backward"></i> Back</button>&nbsp;' + '<button type="button" class="btn btn-primary next">Next <i class="icon-forward icon-white"></i></button>' + '<button type="button" class="btn btn-primary finish">Finish</button>'),

    initialize : function() {
        this.title = this.options.title;
        this.sections = this.options.sections;
        this.render();

        // Adjust next/prev based on model
        this.model.on("change", this.renderNextPrev, this);

        // Go to appropriate section TODO
        this.showSection(0);
    },

    events : {
        "tap .next" : "nextSection",
        "tap .prev" : "prevSection",
        "tap .finish" : "finish",
        "click a.section-crumb" : "crumbSection"
    },

    finish : function() {
        // Validate current section
        var section = this.sections[this.section];
        if (section.validate()) {
            if (this.options.onFinish)
                this.options.onFinish();
        }
    },

    crumbSection : function(e) {
        // Go to section
        var index = parseInt(e.target.getAttribute("data-value"));
        this.showSection(index);
    },

    getNextSectionIndex : function() {
        var i = this.section + 1;
        while (i < this.sections.length) {
            if (this.sections[i].shouldBeVisible())
                return i;
            i++;
        }
    },

    getPrevSectionIndex : function() {
        var i = this.section - 1;
        while (i >= 0) {
            if (this.sections[i].shouldBeVisible())
                return i;
            i--;
        }
    },

    nextSection : function() {
        // Validate current section
        var section = this.sections[this.section];
        if (section.validate()) {
            this.showSection(this.getNextSectionIndex());
        }
    },

    prevSection : function() {
        this.showSection(this.getPrevSectionIndex());
    },

    showSection : function(index) {
        this.section = index;

        _.each(this.sections, function(s) {
            s.$el.hide();
        });
        this.sections[index].$el.show();

        // Setup breadcrumbs
        var tmpl = '<% _.each(sections, function(s, i) { %> <li><a href="#" class="section-crumb" data-value="<%=i%>"><%=s.title%></a> <span class="divider">/</span></li> <% }); %>';
        var visibleSections = _.filter(_.first(this.sections, index + 1), function(s) {
            return s.shouldBeVisible()
        });
        this.$(".breadcrumb").html(_.template(tmpl, {
            sections : _.initial(visibleSections)
        }) + _.template('<li class="active"><%=title%></li>', _.last(visibleSections)));
        
        this.renderNextPrev();
    },
    
    renderNextPrev : function() {
        // Setup next/prev buttons
        this.$(".prev").toggle(this.getPrevSectionIndex() !== undefined);
        this.$(".next").toggle(this.getNextSectionIndex() !== undefined);
        this.$(".finish").toggle(this.getNextSectionIndex() === undefined);
    },

    render : function() {
        this.$el.html(this.template(this));

        // Add sections
        var sectionsEl = this.$(".sections");
        _.each(this.sections, function(s) {
            sectionsEl.append(s.$el);
        });

        return this;
    }

});

surveys.Section = Backbone.View.extend({
    className : "section",
    template : _.template('<h3><%=title%></h3><div class="contents"></div>'),

    initialize : function() {
        this.title = this.options.title;
        this.contents = this.options.contents;

        // Always invisible initially
        this.$el.hide();
        this.render();
    },

    shouldBeVisible : function() {
        if (!this.options.conditional)
            return true;
        return this.options.conditional(this.model);
    },

    validate : function() {
        // Get all visible items
        var items = _.filter(this.contents, function(c) {
            return c.visible && c.validate;
        });
        return !_.any(_.map(items, function(item) {
            return item.validate();
        }));
    },

    render : function() {
        this.$el.html(this.template(this));

        // Add contents (questions, mostly)
        var contentsEl = this.$(".contents");
        _.each(this.contents, function(c) {
            contentsEl.append(c.$el);
        });

        return this;
    }

});

surveys.Question = Backbone.View.extend({
    className : "question",

    template : _.template('<div class="prompt"><%=options.prompt%><%=renderRequired()%></div><div class="answer"></div>'),

    renderRequired : function() {
        if (this.required)
            return '&nbsp;<span class="required">*</span>';
        return '';
    },

    validate : function() {
        var val;

        // Check required
        if (this.required) {
            if (this.model.get(this.id) === undefined || this.model.get(this.id) === null || this.model.get(this.id) === "")
                val = "Required";
        }

        // Check custom validation
        if (!val && this.options.validate) {
            val = this.options.validate();
        }

        // Show validation results TODO
        if (val) {
            this.$el.addClass("invalid");
        } else {
            this.$el.removeClass("invalid");
        }

        return val;
    },

    updateVisibility : function(e) {
        // slideUp/slideDown
        if (this.shouldBeVisible() && !this.visible)
            this.$el.slideDown();
        if (!this.shouldBeVisible() && this.visible)
            this.$el.slideUp();
        this.visible = this.shouldBeVisible();
    },

    shouldBeVisible : function() {
        if (!this.options.conditional)
            return true;
        return this.options.conditional(this.model);
    },

    initialize : function() {
        // Adjust visibility based on model
        this.model.on("change", this.updateVisibility, this);

        // Re-render based on model changes
        this.model.on("change:" + this.id, this.render, this);

        this.required = this.options.required;

        this.render();
    },

    render : function() {
        this.$el.html(this.template(this));

        // Render answer
        this.renderAnswer(this.$(".answer"));

        this.$el.toggle(this.shouldBeVisible());
        this.visible = this.shouldBeVisible();
        return this;
    }

});

surveys.RadioQuestion = surveys.Question.extend({
    events : {
        "checked" : "checked",
    },

    checked : function(e) {
        var index = parseInt(e.target.getAttribute("data-value"));
        var value = this.options.options[index][0];
        this.model.set(this.id, value);
    },

    renderAnswer : function(answerEl) {
        answerEl.html(_.template('<div class="radio-group"><%=renderRadioOptions()%></div>', this));
    },

    renderRadioOptions : function() {
        html = "";
        var i;
        for ( i = 0; i < this.options.options.length; i++)
            html += _.template('<div class="radio-button <%=checked%>" data-value="<%=position%>"><%=text%></div>', {
                position : i,
                text : this.options.options[i][1],
                checked : this.model.get(this.id) === this.options.options[i][0] ? "checked" : ""
            });

        return html;
    }

});

surveys.DropdownQuestion = surveys.Question.extend({
    events : {
        "change" : "changed",
    },

    changed : function(e) {
        var val = $(e.target).val();
        if (val == "") {
            this.model.set(this.id, null);
        } else {
            var index = parseInt(val);
            var value = this.options.options[index][0];
            this.model.set(this.id, value);
        }
    },

    renderAnswer : function(answerEl) {
        answerEl.html(_.template('<select id="source_type"><%=renderDropdownOptions()%></select>', this));
    },

    renderDropdownOptions : function() {
        html = "";

        // Add empty option
        html += '<option value=""></option>';

        var i;
        for ( i = 0; i < this.options.options.length; i++) {
            html += _.template('<option value="<%=position%>" <%=selected%>><%-text%></option>', {
                position : i,
                text : this.options.options[i][1],
                selected : this.model.get(this.id) === this.options.options[i][0] ? 'selected="selected"' : ""
            });
        }

        return html;
    }

});

surveys.MulticheckQuestion = surveys.Question.extend({
    events : {
        "checked" : "checked",
    },

    checked : function(e) {
        // Get all checked
        var value = [];
        var opts = this.options.options;
        this.$(".checkbox").each(function(index) {
            if ($(this).hasClass("checked"))
                value.push(opts[index][0]);
        });
        this.model.set(this.id, value);
    },

    renderAnswer : function(answerEl) {
        var i;
        for ( i = 0; i < this.options.options.length; i++)
            answerEl.append($(_.template('<div class="checkbox <%=checked%>" data-value="<%=position%>"><%=text%></div>', {
                position : i,
                text : this.options.options[i][1],
                checked : (this.model.get(this.id) && _.contains(this.model.get(this.id), this.options.options[i][0])) ? "checked" : ""
            })));
    }

});

surveys.TextQuestion = surveys.Question.extend({
    renderAnswer : function(answerEl) {
        if (this.options.multiline) {
            answerEl.html(_.template('<textarea/>', this));
            answerEl.find("textarea").val(this.model.get(this.id));
        } else {
            answerEl.html(_.template('<input type="text"/>', this));
            answerEl.find("input").val(this.model.get(this.id));
        }
    },

    events : {
        "change" : "changed"
    },
    changed : function() {
        this.model.set(this.id, this.$(this.options.multiline ? "textarea" : "input").val());
    }

});

surveys.NumberQuestion = surveys.Question.extend({
    renderAnswer : function(answerEl) {
        answerEl.html(_.template('<input type="number"/>', this));
        answerEl.find("input").val(this.model.get(this.id));
    },

    events : {
        "change" : "changed"
    },
    changed : function() {
        this.model.set(this.id, parseFloat(this.$("input").val()));
    }

});

surveys.PhotoQuestion = surveys.Question.extend({
    renderAnswer : function(answerEl) {
        answerEl.html(_.template('<img style="max-width: 100px;" src="images/camera-icon.jpg"/>', this));
    },

    events : {
        "tap img" : "takePicture"
    },

    takePicture : function() {
        alert("In an app, this would launch the camera activity as in mWater native apps.");
    }

});

surveys.DateQuestion = surveys.Question.extend({
    events : {
        "change" : "changed"
    },

    changed : function() {
        this.model.set(this.id, this.$el.find('input[name="date"]').val());
    },
    renderAnswer : function(answerEl) {
        answerEl.html(_.template('<input name="date" />', this));

        answerEl.find('input').val(this.model.get(this.id));

        answerEl.find('input').scroller({
            preset : 'date',
            theme : 'ios',
            display : 'modal',
            mode : 'scroller',
            dateOrder : 'mmD ddyy',
        });
    },

});

var utils = utils || {};

(function() {
	// Creates a 128-bit uid in hex
	utils.createUid = function() {
		s = "";
		var i;
		for (i = 0; i < 8; i++)
			s = s + Math.floor(Math.random() * 0x10000 /* 65536 */).toString(16);
		return s;
	};

	utils.parseQuery = function() {
		var nvpair = {};
		var qs = window.location.search.replace('?', '');
		var pairs = qs.split('&');
		$.each(pairs, function(i, v) {
			var pair = v.split('=');
			nvpair[pair[0]] = pair[1];
		});
		return nvpair;
	};

	/* Simple rectangle */
	utils.Rect = function(x1, y1, x2, y2) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	};

	utils.Rect.prototype.contains = function(rect) {
		if (rect.y1 < this.y1 || rect.y2 > this.y2)
			return false;
		if (this.x2 >= this.x1) {
			return (rect.x1 <= rect.x2 && rect.x1 >= this.x1 && rect.x2 <= this.x2);
		}

		if (rect.x2 >= rect.x1) {
			return (rect.x1 >= this.x1 || rect.x1 <= this.x2) && (rect.x2 <= this.x2 || rect.x2 >= this.x1);
		}

		return (rect.x1 >= this.x1 && rect.x2 <= this.x2);
	};

	utils.Rect.prototype.pointWithin = function(x, y) {
		if (y < this.y1 || y > this.y2)
			return false;

		if (this.x2 >= this.x1) {
			return (x >= this.x1 && x <= this.x2);
		}

		return (x >= this.x1 || x <= this.x2);
	};

	// Gets string representing relative location of pt2 from pt1
	utils.getRelativeLocation = function (x1, y1, x2, y2) {
		// Convert to relative position (approximate)
		var dy = (y2 - y1) / 57.3 * 6371000;
		var dx = Math.cos(y1 / 57.3) * (x2 - x1) / 57.3 * 6371000;

		// Determine direction and angle
		var dist = Math.sqrt(dx * dx + dy * dy);
		var angle = 90 - (Math.atan2(dy, dx) * 57.3);
		if (angle < 0)
			angle += 360;
		if (angle > 360)
			angle -= 360;

		// Get approximate direction
		var compassDir = (Math.floor((angle + 22.5) / 45)) % 8;
		var compassStrs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];

		if (dist > 1000)
			return (dist / 1000).toFixed(1) + "km " + compassStrs[compassDir];
		else
			return (dist).toFixed(0) + "m " + compassStrs[compassDir];
	};

	// Checks if a date is today
	utils.isToday = function(msSinceEpoch) {
		return new Date(msSinceEpoch).toLocaleDateString() == new Date().toLocaleDateString();
	};

})()
//     Zepto.js
//     (c) 2010-2012 Thomas Fuchs
//     Zepto.js may be freely distributed under the MIT license.

;(function($) {

    // Convert clicks into taps unless touch activity detected
    var touchActivity = false;
    $(document).on("touchstart touchmove", function(e) {
        touchActivity = true;
    });

    $(document).on('mouseup', function(e) {
        if (!touchActivity)
            $(e.target).trigger('tap');
    });

    var touch = {}, touchTimeout, tapTimeout, swipeTimeout, longTapDelay = 750, longTapTimeout

    function parentIfText(node) {
        return 'tagName' in node ? node : node.parentNode
    }

    function swipeDirection(x1, x2, y1, y2) {
        var xDelta = Math.abs(x1 - x2), yDelta = Math.abs(y1 - y2)
        return xDelta >= yDelta ? (x1 - x2 > 0 ? 'Left' : 'Right') : (y1 - y2 > 0 ? 'Up' : 'Down')
    }

    function longTap() {
        longTapTimeout = null
        if (touch.last) {
            touch.el.trigger('longTap')
            touch = {}
        }
    }

    function cancelLongTap() {
        if (longTapTimeout)
            clearTimeout(longTapTimeout)
        longTapTimeout = null
    }

    function cancelAll() {
        if (touchTimeout)
            clearTimeout(touchTimeout)
        if (tapTimeout)
            clearTimeout(tapTimeout)
        if (swipeTimeout)
            clearTimeout(swipeTimeout)
        if (longTapTimeout)
            clearTimeout(longTapTimeout)
        touchTimeout = tapTimeout = swipeTimeout = longTapTimeout = null
        touch = {}
    }


    $(document).ready(function() {
        var now, delta

        $(document.body).bind('touchstart', function(e) {
            now = Date.now()
            delta = now - (touch.last || now)
            touch.el = $(parentIfText(e.originalEvent.touches[0].target))
            touchTimeout && clearTimeout(touchTimeout)
            touch.x1 = e.originalEvent.touches[0].pageX
            touch.y1 = e.originalEvent.touches[0].pageY
            if (delta > 0 && delta <= 250)
                touch.isDoubleTap = true
            touch.last = now
            longTapTimeout = setTimeout(longTap, longTapDelay)
        }).bind('touchmove', function(e) {
            cancelLongTap()
            touch.x2 = e.originalEvent.touches[0].pageX
            touch.y2 = e.originalEvent.touches[0].pageY
        }).bind('touchend', function(e) {
            cancelLongTap()

            // swipe
            if ((touch.x2 && Math.abs(touch.x1 - touch.x2) > 30) || (touch.y2 && Math.abs(touch.y1 - touch.y2) > 30))

                swipeTimeout = setTimeout(function() {
                    if (touch.el) {
                        touch.el.trigger('swipe')
                        touch.el.trigger('swipe' + (swipeDirection(touch.x1, touch.x2, touch.y1, touch.y2)))
                    }
                    touch = {}
                }, 0)

            // normal tap
            else if ('last' in touch)

                // delay by one tick so we can cancel the 'tap' event if 'scroll' fires
                // ('tap' fires before 'scroll')
                tapTimeout = setTimeout(function() {

                    // trigger universal 'tap' with the option to cancelTouch()
                    // (cancelTouch cancels processing of single vs double taps for faster 'tap' response)
                    var event = $.Event('tap')
                    event.cancelTouch = cancelAll
                    if (touch.el)
                        touch.el.trigger(event)

                    // trigger double tap immediately
                    if (touch.isDoubleTap) {
                        if (touch.el)
                            touch.el.trigger('doubleTap')
                        touch = {}
                    }

                    // trigger single tap after 250ms of inactivity
                    else {
                        touchTimeout = setTimeout(function() {
                            touchTimeout = null
                            if (touch.el)
                                touch.el.trigger('singleTap')
                            touch = {}
                        }, 250)
                    }

                }, 0)

        }).bind('touchcancel', cancelAll)

        $(window).bind('scroll', cancelAll)
    });
    ['swipe', 'swipeLeft', 'swipeRight', 'swipeUp', 'swipeDown', 'doubleTap', 'tap', 'singleTap', 'longTap'].forEach(function(m) {
        $.fn[m] = function(callback) {
            return this.bind(m, callback)
        }

    })

})(jQuery);var pages = pages || {}

/* Example survey */
pages.ExampleSplashSurvey = function(uid) {
    var page = this;

    function createSurvey(model) {
        var sections = [];
        var questions = [];
        questions.push(new RadioQuestion({
            id : "q1",
            model : model,
            required : true,
            prompt : "Has post-installation water analysis EVER been completed for the site?",
            options : [[true, "Yes"], [false, "No"]],
        }));

        questions.push(new DateQuestion({
            id : "q2",
            model : model,
            required : true,
            prompt : "When was the last water analysis completed?",
            conditional : function(m) {
                return m.get("q1") === true;
            }

        }));

        questions.push(new RadioQuestion({
            id : "q3",
            model : model,
            required : true,
            prompt : "Are all of the water quality parameters below the threshold limits?",
            options : [[true, "Yes"], [false, "No"]],
            conditional : function(m) {
                return m.get("q1") === true;
            }
        }));

        questions.push(new MulticheckQuestion({
            id : "q4",
            model : model,
            prompt : "Which parameters exceed the limits?",
            options : [["tc", "Total Coliforms"], ["ecoli", "E.Coli"], ["turbidity", "Turbidity"], ["ph", "pH"], ["iron", "Iron"], ["other", "Other"]],
            conditional : function(m) {
                return m.get("q3") === false && m.get("q1") === true;
            }
        }));

        questions.push(new NumberQuestion({
            id : "q5",
            model : model,
            prompt : "What is the concentration of Total Coliforms?",
            conditional : function(m) {
                return m.get("q3") === false && m.get("q4") && _.contains(m.get("q4"), "tc") && m.get("q1") === true;
            }
        }));

        questions.push(new NumberQuestion({
            id : "q6",
            model : model,
            prompt : "What is the concentration of E. Coli?",
            conditional : function(m) {
                return m.get("q3") === false && m.get("q4") && _.contains(m.get("q4"), "ecoli") && m.get("q1") === true;
            }
        }));

        questions.push(new NumberQuestion({
            id : "q7",
            model : model,
            prompt : "What is the turbidity?",
            conditional : function(m) {
                return m.get("q3") === false && m.get("q4") && _.contains(m.get("q4"), "turbidity") && m.get("q1") === true;
            }
        }));
        
        questions.push(new NumberQuestion({
            id : "q8",
            model : model,
            prompt : "What is the pH?",
            conditional : function(m) {
                return m.get("q3") === false && m.get("q4") && _.contains(m.get("q4"), "ph") && m.get("q1") === true;
            }
        }));
        
        questions.push(new NumberQuestion({
            id : "q9",
            model : model,
            prompt : "What is the concentration of iron?",
            conditional : function(m) {
                return m.get("q3") === false && m.get("q4") && _.contains(m.get("q4"), "iron") && m.get("q1") === true;
            }
        }));

        sections.push( section = new Section({
            title : "Water Quality",
            contents : questions
        }));

        questions = []
        questions.push(new RadioQuestion({
            id : "q10",
            model : model,
            prompt : "Is there a cover for the system?",
            options : [[true, "Yes"], [false, "No"]],
        }));

        questions.push(new RadioQuestion({
            id : "q11",
            model : model,
            prompt : "Is there a lock and key for the cover?",
            options : [[true, "Yes"], [false, "No"]],
            conditional : function(m) {
                return m.get("q10") === true;
            }

        }));

        questions.push(new RadioQuestion({
            id : "q12",
            model : model,
            prompt : "Was the cover locked when you arrived on site?",
            options : [[true, "Yes"], [false, "No"]],
            conditional : function(m) {
                return m.get("q10") === true && m.get("q11") === true;
            }

        }));

        questions.push(new RadioQuestion({
            id : "q13",
            model : model,
            prompt : "Is there ANY dust built up on the system?",
            options : [[true, "Yes"], [false, "No"]],
        }));

        questions.push(new RadioQuestion({
            id : "q14",
            model : model,
            prompt : "Is there ANY grease collected on the system?",
            options : [[true, "Yes"], [false, "No"]],
        }));

        questions.push(new PhotoQuestion({
            id : "q15",
            model : model,
            prompt : "Please take a picture of any dust or grease on the system.",
            conditional : function(m) {
                return m.get("q13") === true || m.get("q14") === true;
            }
        }));

        sections.push( section = new Section({
            title : "Water System",
            contents : questions
        }));

        var survey = new Survey({
            title : "",
            sections : sections, 
            onFinish : function() {
                alert("Results recorded");
                page.pager.closePage();
            }
        });
        
        return survey;

    }

    this.create = function(callback) {
        this.template("example_survey", {}, function(out) {
            page.$el.html(out);

            // Create model
            page.surveyModel = new SurveyModel();

            // Save regularly
            page.surveyModel.on("change", function() {
                localStorage.setItem("examplesurvey", JSON.stringify(page.surveyModel.toJSON()));    
            });
            
            // Create survey
            page.survey = createSurvey(page.surveyModel);
            page.$(".page").append(page.survey.$el);

            callback();
        });

    };
    
    this.activate = function() {
        // Load model
        if (localStorage.getItem("examplesurvey")) {
            page.surveyModel.set(JSON.parse(localStorage.getItem("examplesurvey")))
        }
    };
    
    this.deactivate = function() {
        localStorage.setItem("examplesurvey", JSON.stringify(page.surveyModel.toJSON()));
    };
    
    this.actionbarTitle = "M&E Grading Survey";
    
        this.actionbarMenu = [{
        id : "reset",
        title : "Reset",
    }];

    this.actionbarMenuClick = function(id) {
        if (id == "reset") {
            if (confirm("Reset entire survey?")) {
                page.surveyModel.clear();
            }
        }
    }

}; var pages = pages || {}

/* Example survey */
pages.ExampleSurvey = function(uid) {
    var page = this;

    function createSurvey(model) {
        var survey = (function() {
            var model = new surveys.SurveyModel();
            var sections = [], questions = [];
            // START HERE

            /* Facility Type */

            questions.push(new surveys.DropdownQuestion({
                id : "q1",
                model : model,
                required : true,
                prompt : "What is the type of facility?",

                options : [["PipedWater", "Piped Water"], ["PipedWaterRes", "Piped Water with Service Reservoir"], ["GravityFedPiped", "Gravity-fed Piped Water"], ["BoreholeMech", "Deep Borehole with Mechanized Pumping"], ["BoreholeHand", "Deep Borehole with Handpump"], ["ProtectedSpring", "Protected Spring"], ["DugWellPump", "Dug Well with Handpump/windlass"], ["TreatmentPlant", "Water Treatment Plant"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Choose your survey",
                contents : questions
            }));
            questions = [];

            /* General Information */

            questions.push(new surveys.TextQuestion({
                id : "q2",
                model : model,
                prompt : "Cluster number?",
            }));

            questions.push(new surveys.TextQuestion({
                id : "q3",
                model : model,
                prompt : "Cluster name?",
            }));

            questions.push(new surveys.TextQuestion({
                id : "q4",
                model : model,
                prompt : "What is the name of the community?",
            }));

            questions.push(new surveys.DateQuestion({
                id : "q5",
                model : model,
                prompt : "Date of visit?",
            }));

            questions.push(new surveys.NumberQuestion({
                id : "q6",
                model : model,
                prompt : "How many water samples were taken?",

            }));
            questions.push(new surveys.NumberQuestion({
                id : "q7",
                model : model,
                prompt : "Water sample numbers?",

            }));
            questions.push(new surveys.NumberQuestion({
                id : "q8",
                model : model,
                prompt : "FC/100ml?",

            }));

            sections.push(new surveys.Section({
                model : model,
                title : "General Information",
                contents : questions
            }));

            questions = [];

            /* PipedWater Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q9",
                model : model,
                required : true,
                prompt : "Do any tapstands leak?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q10",
                model : model,
                required : true,
                prompt : "Does surface water collect around any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q11",
                model : model,
                required : true,
                prompt : "Is the area uphill of any tapstand eroded?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q12",
                model : model,
                required : true,
                prompt : "Are pipes exposed close to any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q13",
                model : model,
                required : true,
                prompt : "Is human excreta on the ground within 10m of any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q14",
                model : model,
                required : true,
                prompt : "Is there a sewer within 30m of any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q15",
                model : model,
                required : true,
                prompt : "Has there been discontinuity in the last 10 days at any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q16",
                model : model,
                required : true,
                prompt : "Are there signs of leaks in the mains pipes in the cluster?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q17",
                model : model,
                required : true,
                prompt : "Do the community report any pipe breaks in the last week?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q18",
                model : model,
                required : true,
                prompt : "Is the main pipe exposed anywhere in the cluster?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Piped Water Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "PipedWater";
                }

            }));
            questions = [];

            /* PipedWaterRes Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q19",
                model : model,
                required : true,
                prompt : "Do any standpipes leak at sample sites?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q20",
                model : model,
                required : true,
                prompt : "Does water collect around any sample site?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q21",
                model : model,
                required : true,
                prompt : "Is area uphill eroded at any sample site?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q22",
                model : model,
                required : true,
                prompt : "Are pipes exposed close to any sample site?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q23",
                model : model,
                required : true,
                prompt : "Is human excreta on ground within 10m of standpipe?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q24",
                model : model,
                required : true,
                prompt : "Sewer or latrine within 30m of sample site?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q25",
                model : model,
                required : true,
                prompt : "Has there been discontinuity within last 10 days at sample site?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q26",
                model : model,
                required : true,
                prompt : "Are there signs of leaks in sampling area?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q27",
                model : model,
                required : true,
                prompt : "Do users report pipe breaks in last week?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q28",
                model : model,
                required : true,
                prompt : "Is the supply main exposed in sampling area?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q29",
                model : model,
                required : true,
                prompt : "Do users report pipe breaks in last week?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q30",
                model : model,
                required : true,
                prompt : "Is the service reservoir cracked or leaking?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q31",
                model : model,
                required : true,
                prompt : "Are the air vents or inspection cover insanitary?",

                options : [[true, "Yes"], [false, "No"]],
            }));


            sections.push(new surveys.Section({
                model : model,
                title : "Piped Water with Service Reservoir Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "PipedWaterRes";
                }

            }));
            questions = [];

            /* GravityFedPiped Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q32",
                model : model,
                required : true,
                prompt : "Does the pipe leak between the source and storage tank?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q33",
                model : model,
                required : true,
                prompt : "Is the storage tank cracked, damaged or leak?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q34",
                model : model,
                required : true,
                prompt : "Are the vents and covers on the tank damaged or open?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q35",
                model : model,
                required : true,
                prompt : "Do any tapstands leak?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q36",
                model : model,
                required : true,
                prompt : "Does surface water collect around any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q37",
                model : model,
                required : true,
                prompt : "Is the area uphill of any tapstand eroded?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q38",
                model : model,
                required : true,
                prompt : "Are pipes exposed close to any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q39",
                model : model,
                required : true,
                prompt : "Is human excreta on the ground within 10m of any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q40",
                model : model,
                required : true,
                prompt : "Has there been discontinuity n the last 10 days at any tapstand?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q41",
                model : model,
                required : true,
                prompt : "Are there signs of leaks in the main supply pipe in the system?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q42",
                model : model,
                required : true,
                prompt : "Do the community report any pipe breaks in the last week?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q43",
                model : model,
                required : true,
                prompt : "Is the main supply pipe exposed anywhere in the system?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Gravity-fed Piped Water Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "GravityFedPiped";
                }

            }));
            questions = [];

            /* BoreholeMech Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q44",
                model : model,
                required : true,
                prompt : "Is there a latrine or sewer within 100m of pumphouse?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q45",
                model : model,
                required : true,
                prompt : "Is the nearest latrine unsewered?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q46",
                model : model,
                required : true,
                prompt : "Is there any source of other pollution within 50m?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q47",
                model : model,
                required : true,
                prompt : "Is there an uncapped well within 100m?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q48",
                model : model,
                required : true,
                prompt : "Is the drainage around pumphouse faulty?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q49",
                model : model,
                required : true,
                prompt : "Is the fencing damaged allowing animal entry?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q50",
                model : model,
                required : true,
                prompt : "Is the floor of the pumphouse permeable to water?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q51",
                model : model,
                required : true,
                prompt : "Does water forms pools in the pumphouse?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q52",
                model : model,
                required : true,
                prompt : "Is the well seal insanitary?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Deep Borehole with Mechanized Pumping Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "BoreholeMech";
                }

            }));
            questions = [];


            /* BoreholeHand Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q53",
                model : model,
                required : true,
                prompt : "Is there a latrine within 10m of the borehole?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q54",
                model : model,
                required : true,
                prompt : "Is there a latrine uphill of the borehole?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q55",
                model : model,
                required : true,
                prompt : "Are there any other sources of pollution within 10m of borehole? (e.g. animal breeding, cultivation, roads, industry etc)",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q56",
                model : model,
                required : true,
                prompt : "Is the drainage faulty allowing ponding within 2m of the borehole?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q57",
                model : model,
                required : true,
                prompt : "Is the drainage channel cracked, broken or need cleaning?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q58",
                model : model,
                required : true,
                prompt : "Is the fence missing or faulty?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q59",
                model : model,
                required : true,
                prompt : "Is the apron less than 1m in radius?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q60",
                model : model,
                required : true,
                prompt : "Does spilt water collect in the apron area?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q61",
                model : model,
                required : true,
                prompt : "Is the apron cracked or damaged?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q62",
                model : model,
                required : true,
                prompt : "Is the handpump loose at the point of attachment to apron?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Deep Borehole with Handpump Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "BoreholeHand";
                }

            }));
            questions = [];


            /* ProtectedSpring Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q63",
                model : model,
                required : true,
                prompt : "Is the spring unprotected?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q64",
                model : model,
                required : true,
                prompt : "Is the masonary protecting the spring faulty?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q65",
                model : model,
                required : true,
                prompt : "Is the backfill area behind the retaining wall eroded?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q66",
                model : model,
                required : true,
                prompt : "Does spilt water flood the collection area?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q67",
                model : model,
                required : true,
                prompt : "Is the fence absent or faulty?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q68",
                model : model,
                required : true,
                prompt : "Can animals have access within 10m of the spring?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q69",
                model : model,
                required : true,
                prompt : "Is there a latrine uphill and/or within 30m of the spring?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q70",
                model : model,
                required : true,
                prompt : "Does surface water collect uphill of the spring?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q71",
                model : model,
                required : true,
                prompt : "Is the diversion ditch above the spring absent or non-functional?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q72",
                model : model,
                required : true,
                prompt : "Are there any other sources of pollution uphill of the spring? (e.g. solid waste)",

                options : [[true, "Yes"], [false, "No"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Protected Spring Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "ProtectedSpring";
                }

            }));
            questions = [];


            /* DugWellPump Survey surveys.Section */

            questions.push(new surveys.RadioQuestion({

                id : "q73",
                model : model,
                required : true,
                prompt : "Is there a latrine within 10m of the well?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q74",
                model : model,
                required : true,
                prompt : "Is the nearest latrine uphill of the well?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q75",
                model : model,
                required : true,
                prompt : "Is there any other source of pollution within 10m of well? (e.g. animal breeding, cultivation, roads, industry etc)",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q76",
                model : model,
                required : true,
                prompt : "Is the drainage faulty allowing ponding within 2m of the well?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q77",
                model : model,
                required : true,
                prompt : "Is the drainage channel cracked, broken or need cleaning?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q78",
                model : model,
                required : true,
                prompt : "Is the fence missing or faulty?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q79",
                model : model,
                required : true,
                prompt : "Is the cement less than 1m in radius around the top of the well?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q80",
                model : model,
                required : true,
                prompt : "Does spilt water collect in the apron area?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q81",
                model : model,
                required : true,
                prompt : "Are there cracks in the cement floor?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q82",
                model : model,
                required : true,
                prompt : "Is the handpump loose at the point of attachment to well head?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            questions.push(new surveys.RadioQuestion({

                id : "q83",
                model : model,
                required : true,
                prompt : "Is the well-cover insanity?",

                options : [[true, "Yes"], [false, "No"]],
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Dug Well with Handpump/windlass Survey",
                contents : questions,
                conditional : function(m) {
                    return m.get("q1") === "DugWellPump";
                }

            }));
            questions = [];


            /* Comments surveys.Section */

            questions.push(new surveys.TextQuestion({
                id : "q100",
                model : model,
                prompt : "Additional comments"
            }));

            questions.push(new surveys.TextQuestion({
                id : "q101",
                model : model,
                prompt : "Inspector name",
            }));

            sections.push(new surveys.Section({
                model : model,
                title : "Additional comments",
                contents : questions
            }));
            questions = [];


            // END HERE
            var view = new surveys.SurveyView({
                title : 'WHO UNICEF Sanitary Inspection and Pollution Risk Assessment',
                sections : sections,
                model : model
            });
            return {
                model : model,
                view : view
            };
        })();

        return survey;
    }


    this.create = function(callback) {
        this.template("example_survey", {}, function(out) {
            page.$el.html(out);

            page.survey = createSurvey();
            page.survey.view.options.onFinish = function() {
                alert("Results recorded");
                page.pager.closePage();
            };

            // Save regularly
            page.survey.model.on("change", function() {
                localStorage.setItem("examplesurvey", JSON.stringify(page.survey.model.toJSON()));
            });

            // Create survey
            page.$(".page").append(page.survey.view.$el);

            callback();
        });

    };

    this.activate = function() {
        // Load model
        if (localStorage.getItem("examplesurvey")) {
            page.survey.model.set(JSON.parse(localStorage.getItem("examplesurvey")))
        }
    };

    this.deactivate = function() {
        localStorage.setItem("examplesurvey", JSON.stringify(page.survey.model.toJSON()));
    };

    this.actionbarTitle = "Survey";

    this.actionbarMenu = [{
        id : "reset",
        title : "Reset",
    }];

    this.actionbarMenuClick = function(id) {
        if (id == "reset") {
            if (confirm("Reset entire survey?")) {
                page.survey.model.clear();
            }
        }
    }

};
var pages = pages || {}

/* Login page of application */
pages.Login = function (success) {
    var page = this;
    
    function login() {
        page.$("#login_button").attr("disabled", true);

        var username = page.$("#login_username").val();
        var password = page.$("#login_password").val();
        page.syncServer.login(username, password, function() {
            if (success)
                success(username);
            else
                page.pager.closePage("Main");
        }, function() {
            alert("Login failed");
            page.$("#login_button").attr("disabled", false);
        });
    }
    
    function signup() {
        page.$("#signup_button").attr("disabled", true);

        var email = page.$("#signup_email").val();
        var username = page.$("#signup_username").val();
        var password = page.$("#signup_password").val();
        page.syncServer.signup(email, username, password, function() {
            if (success)
                success(username);
            else
                page.pager.closePage("Main");
        }, function() {
            alert("Signup failed");
            page.$("#signup_button").attr("disabled", false);
        });
    }

	this.create = function(callback) {
		this.template("login", null, function(out) {
			page.$el.html(out);
			
            page.$("#form_login").on("submit", function() {
                login();
                return false;
            });
			page.$("#form_signup").on("submit", function() {
                signup();
                return false;
            });
			callback();
		});
	};
};var pages = pages || {}

/* Main page of application */
pages.Main = function() {
    var page = this;

    this.create = function(callback) {
        this.template("main", null, function(out) {
            page.$el.html(out);
            page.$("#sources").on("tap", function() {
                page.pager.loadPage("Sources");
            });
            page.$("#map").on("tap", function() {
                page.pager.loadPage("Map");
            });
            page.$("#tests").on("tap", function() {
                page.pager.loadPage("Tests");
            });
            page.$("#settings").on("tap", function() {
                page.pager.loadPage("Settings");
            });
            page.$("#sync_cancel").on("tap", function() {
                syncCancel = true;
                page.$("#sync_cancel").attr("disabled", true);
            });

            callback();
        });
    };

    this.activate = function() {
        // If auto sync
        if (localStorage.getItem("autoSync") != "false")
            synchronize();
    };

    this.actionbarMenu = [{
        id : "sync",
        title : "Sync",
        icon : "images/sync.png",
        ifRoom : true
    }, {
        id : "logout",
        title : "Logout"
    }];

    this.actionbarTitle = "mWater";

    var syncInProgress = false;
    var syncCancel = false;

    function syncSuccess() {
        syncInProgress = false;

        page.$("#sync_error").hide();
        page.$("#sync_progress").hide();
        page.$("#sync_success").show().delay(2000).slideUp();
    }

    function syncError(msg, error) {
        syncInProgress = false;

        console.warn("SyncError:" + JSON.stringify(error || 'Unknown') + ":" + msg);

        page.$("#sync_progress").hide();
        page.$("#sync_success").hide();
        page.$("#sync_error").text("Unable to synchronize: " + msg).show().delay(5000).slideUp();
    }

    function uploadImages() {
        // Now upload images
        if (syncCancel) {
            syncError("Cancelled");
            return;
        }

        // If no image upload, go to success
        if (!page.imageManager.uploadImages) {
            syncSuccess();
            return;
        }

        page.imageManager.uploadImages(function(remaining, percentage) {
            page.$("#sync_progress_message").text("Uploading images. " + remaining + " remaining.");
        }, function(remaining) {
            if (remaining > 0)
                uploadImages();
            else
                syncSuccess();
        }, function(error) {
            syncError("Error connecting to server", error.http_status);
        });
    }

    // Synchronize with a position. If position is undefined, degrade gracefully
    function syncWithPosition(position) {
        // Determine which slices to get based on position
        if (position)
            slices = geoslicing.getSlices(1, position.coords.latitude, position.coords.longitude);
        else
            slices = [];

        // Always get own sources
        slices.push("source.created_by:" + page.syncServer.getUsername());

        page.syncClient.sync(slices, uploadImages, function(error) {
            syncError("Error connecting to server", error);
        });
    }

    function synchronize() {
        if (!page.syncClient)
            return;

        if (syncInProgress)
            return;

        if (navigator && navigator.connection && navigator.connection.type) {
              console.log("Connection type: " + navigator.connection.type);
              if (navigator.connection.type == Connection.NONE)
                  return;
        }

        syncInProgress = true;
        syncCancel = false;

        page.$("#sync_cancel").attr("disabled", false);
        page.$("#sync_progress").text("Synchronizing...").show();
        page.$("#sync_error").hide();
        page.$("#sync_success").hide();

        // Replenish source codes first
        page.sourceCodeManager.replenishCodes(5, function() {
            // Sync based on position
            navigator.geolocation.getCurrentPosition(syncWithPosition, function(error) {
                // Notify that unable to get position
                page.$("#sync_progress").text("Synchronizing without location...").show();
                syncWithPosition();
            });
        }, function(error) {
            syncError("Error connecting to server", error);
        });
    }


    this.actionbarMenuClick = function(id) {
        // Handle sync event
        if (id == "sync") {
            synchronize();
        } else if (id == "logout") {
            function gotoLoginPage() {
                // Close and go to login page
                page.pager.closePage("Login");
            }

            // Always allow logout
            this.syncServer.logout(gotoLoginPage, gotoLoginPage);
        } else
            alert(id);
    };
};
var pages = pages || {}

pages.Map = function(center) {
    var map;
    var sourceMap;
    var page = this;

    function sourceClick(source, marker) {
        // Synchronize single source
        if (page.syncClient) {
            sourceMap.displayStatus("Loading source...");

            slices = ["source.uid:" + source.uid];
            page.syncClient.sync(slices, function() {
                sourceMap.displayStatus();
                page.pager.loadPage("Source", [source.uid]);
            }, function(error) {
                sourceMap.displayStatus();
                alert("Unable to connect to server");
            });
        } else
            page.pager.loadPage("Source", [source.uid]);
    }

    function centerCurrentLocation() {
        navigator.geolocation.getCurrentPosition(function(position) {
            sourceMap.gmap.setCenter(new google.maps.LatLng(position.coords.latitude, position.coords.longitude));
        });
    }

    var myLocationMarker, locationWatchId;

    function addMyLocation() {
        function geolocationSuccess(pos) {
            if (sourceMap) {
                var me = new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude);
                console.log("Got position: " + pos.coords.latitude + "," + pos.coords.longitude)
                myLocationMarker.setPosition(me);
            }
        }

        function geolocationError() {
            // ...
        }

        if (navigator.geolocation && !locationWatchId)
            locationWatchId = navigator.geolocation.watchPosition(geolocationSuccess, geolocationError, {
                maximumAge : 3000,
                enableHighAccuracy : true
            });
    }

    function removeMyLocation() {
        // End location watch
        if (locationWatchId)
            navigator.geolocation.clearWatch(locationWatchId);
        locationWatchId = null;
    }

    var firstActivate = true;

    function uploadData(success) {
        if (!page.syncClient) {
            if (success)
                success();
            return;
        }

        page.syncClient.upload(success, page.error);
    }

    var mapUnavailable = false;

    this.create = function(callback) {
        this.template("map", null, function(out) {
            page.$el.html(out);
            
            // Check if connection available
            console.log("Checking connection...")
            if (navigator && navigator.connection && navigator.connection.type) {
                console.log("Connection type: " + navigator.connection.type);
                if (navigator.connection.type == Connection.NONE) {
                    alert("Map is only available with netword connection");
                    mapUnavailable = true;
                    callback();
                    return;
                }
            }

            $.getScript("https://www.google.com/jsapi").done(function() {
                google.load("maps", 3, {
                    "other_params" : "sensor=true",
                    "callback" : function() {
                        // First upload data
                        uploadData(function() {
                            var mapOptions = {
                                zoom : 13,
                                center : center ? new google.maps.LatLng(center.latitude, center.longitude) : undefined,
                                mapTypeId : google.maps.MapTypeId.ROADMAP
                            }

                            sourceMap = new SourceMap($("#map_canvas").get(0), page.syncServer.baseUrl, mapOptions, sourceClick);

                            if (!center)
                                centerCurrentLocation();

                            // Put location on map
                            myLocationMarker = new google.maps.Marker({
                                clickable : false,
                                icon : new google.maps.MarkerImage('images/my_location.png', new google.maps.Size(22, 22), new google.maps.Point(0, 0), new google.maps.Point(11, 11)),
                                shadow : null,
                                zIndex : 1000000,
                                map : sourceMap.gmap
                            });

                            addMyLocation();
                        });
                    }

                });
            });
            callback();
        });
    };

    this.activate = function() {
        if (mapUnavailable) {
            page.pager.closePage();
            return;
        }
            
        if (!firstActivate) {
            addMyLocation();

            // Upload data to ensure latest version
            uploadData(function() {
                if (sourceMap)
                    sourceMap.updateMarkers();
            });
        }

        firstActivate = false;
    };

    this.deactivate = function() {
        removeMyLocation();
    };

}
var pages = pages || {}

/* Creates a source */
pages.NewSource = function(location, result) {
	var page = this;

	function createSource() {
		// Get a source code
		page.sourceCodeManager.requestCode(function(code) {
			uid = utils.createUid();

			// Create source
			source = {
				uid : uid,
				code : code,
				name : page.$("#name").val(),
				desc : page.$("#desc").val(),
				source_type : parseInt(page.$("#source_type").val()),
				created_by : page.syncServer.getUsername()
			};
			
			// Add location 
			if (location)
				_.extend(source, location);

			page.model.transaction(function(tx) {
				page.model.insertRow(tx, "sources", source);
			}, page.error, function() {
				if (result)
					result(uid);
				else
					page.pager.closePage("Source", [uid, page.$("#set_location").hasClass("checked")]);
			});

		}, function(error) {
			alert("Unable to generate source id")
		});
	}


	this.create = function(callback) {
		this.template("new_source", {
			sourceTypes : page.model.sourceTypes
		}, function(out) {
			page.$el.html(out);

			// Hide location button if
			if (location)
				page.$("#set_location").hide();

			page.$("#create_button").on("tap", function() {
				if (page.$("#source_type").val() == "")
					alert("Select source type");
				else
					createSource();
			});
			page.$("#cancel_button").on("tap", function() {
				if (result)
					result();
				else
					page.pager.closePage();
			});
			callback();
		});
	};
};var pages = pages || {}

/* Creates a test */
pages.NewTest = function(sourceUid) {
	var page = this;

	function createTest(testType) {

		function createTestForSample(sampleUid) {
			uid = utils.createUid();

			// Create test
			test = {
				uid : uid,
				test_type : testType,
				test_version : 1,
				sample : sampleUid,
				started_on : Math.floor(new Date().getTime() / 1000),
				created_by : page.syncServer.getUsername()
			};

			page.model.transaction(function(tx) {
				page.model.insertRow(tx, "tests", test);
			}, page.error, function() {
				page.pager.closePage("Test_" + testType, [uid]);
			});
		}

		// If for source, create/find sample
		if (sourceUid) {
			// Get samples and see if one already present for same day
			page.model.querySamplesAndTests(sourceUid, function(samples) {
				if (samples.length > 0 && utils.isToday(_.last(samples).sampled_on * 1000)) {
					// Use existing sample
					createTestForSample(_.last(samples).uid);
					return;
				}

				// Create new sample
				var sampleUid = utils.createUid();

				// Create sample
				sample = {
					uid : sampleUid,
					source : sourceUid,
					sampled_on : Math.floor(new Date().getTime() / 1000),
					created_by : page.syncServer.getUsername()
				};
				page.model.transaction(function(tx) {
					page.model.insertRow(tx, "samples", sample);
				}, page.error, function() {
					createTestForSample(sampleUid);
				});

			}, page.error);
		} else
			createTestForSample(null);
	}


	this.create = function(callback) {
		this.template("new_test", {}, function(out) {
			page.$el.html(out);

			page.$("a").on("tap", function() {
				createTest(parseInt(this.id.substr(5)));
				return false;
			});

			callback();
		});
	};
};
var pages = pages || {}

/* Displays a photo */
pages.Photo = function(uid) {
	var page = this;
	
	this.create = function(callback) {
		this.template("photo", null, function(out) {
			page.$el.html(out);

			page.imageManager.getImageUrl(uid, function(url) {
				page.$("#message_bar").hide();
				page.$("#image").attr("src", url).show();
			}, page.error);

			callback();
		});
	}
}
var pages = pages || {}

/* Settings page of application */
pages.Settings = function() {
    var page = this;

    function refresh(callback) {
        var view = {
            offlineSourceCodes : page.sourceCodeManager.getNumberAvailableCodes(),
            username: page.syncServer.getUsername(),
            appVersion : page.appVersion
        }

        page.template("settings", view, function(out) {
            page.$el.html(out);

            page.$("#auto_sync").toggleClass("checked", localStorage.getItem("autoSync") != "false");
            page.$("#auto_sync").on("checked", function() {
                localStorage.setItem("autoSync", page.$("#auto_sync").hasClass("checked") ? "true" : "false");
            });

            page.$("#request_source_codes").on("tap", function() {
                page.sourceCodeManager.replenishCodes(view.offlineSourceCodes + 5, function() {
                    refresh();
                }, function() {
                    alert("Unable to contact server");
                });
            });

            if (!(page.model instanceof MWaterSqlModel))
                page.$(".local_db_block").hide();

            page.$("#reset_database").on("tap", function() {
                if (confirm("Completely reset local database?"))
                    page.model.reset(function() {
                        alert("Reset complete");
                    }, page.error);
            });
            
            if (callback)
                callback();
        });

    }

    this.create = refresh;
};
var pages = pages || {}

/* Displays details of a source */
pages.Source = function(uid, setLocation, hideLocation) {
	this.uid = uid;

	var page = this;
	var source;

	var locationWatchId;
	var position;

	this.refresh = function() {
		function displaySource() {
			// Display photo
			new PhotoDisplayer(page, page.$("#photo"), source, page.error);

			page.$("#location_set").on("tap", function() {
				if (confirm("Set to current location?")) {
					setLocation = true;
					displayLocation();
				}
			});

			page.$("#location_map").on("tap", function() {
				if (source.latitude)
					page.pager.loadPage("Map", [{
						latitude : source.latitude,
						longitude : source.longitude
					}]);
			});

			if (hideLocation)
				page.$("#location").hide();

			page.$("#edit_source_button").on("tap", function() {
				page.pager.loadPage("SourceEdit", [source.uid]);
			});

			page.$("#add_test_button").on("tap", function() {
				page.pager.loadPage("NewTest", [source.uid]);
			});

			page.$("#add_note_button").on("tap", function() {
				page.pager.loadPage("SourceNote", [source.uid]);
			});

			Pager.makeTappable(page.$("#tests"), function(row) {
				// Get test
				page.model.queryTestByUid(row.id, function(test) {
					page.pager.loadPage("Test_" + test.test_type, [test.uid]);
				}, page.error);
			});

			Pager.makeTappable(page.$("#notes"), function(row) {
				page.pager.loadPage("SourceNote", [source.uid, row.id]);
			});

			if (!page.auth.canEdit(source)) {
				page.$("#edit_source_button, #location_set").attr("disabled", true);
			}

			if (!page.auth.canAdd("source_notes")) {
				page.$("#add_note_button").attr("disabled", true);
			}

			if (!page.auth.canAdd("samples")) {
				page.$("#add_test_button").attr("disabled", true);
			}

			if (!hideLocation)
				displayLocation();

			// Fill water analyses
			page.model.querySamplesAndTests(source.uid, function(samples) {
				var view = {
					analyses : []
				}

				_.each(samples, function(sample) {
					_.each(sampleanalysis.getAnalyses(sample), function(anl) {
						anl.sample = sample;
						view.analyses.push(anl);
					});
				});
				page.template("source_analyses", view, $("#analyses"));

				var view = {
					tests : []
				}

				_.each(samples, function(sample) {
					_.each(sample.tests, function(test) {
						test.summary = sampleanalysis.summarizeTest(test);
						view.tests.push(test);
					});
				});
				page.template("source_tests", view, $("#tests"));


			}, page.error);

			// Fill notes
			page.model.querySourceNotes(source.uid, function(notes) {
				var view = {
					notes : notes
				}
				page.template("source_notes", view, $("#notes"));
			}, page.error);
		}


		this.model.querySourceByUid(this.uid, function(src) {
			if (src == null) {
				alert("Source not found");
				page.pager.closePage();
				return;
			}
			source = src;
			page.template("source", source, function(out) {
				page.$el.html(out);
				displaySource();
			});
		}, page.error);
	};

	function displayLocation() {
		if (!source)
			return;

		page.$("#location_map").attr("disabled", !source.latitude);

		// If setting location and position available, set position
		if (setLocation && position) {
			setLocation = false;
			// Set in source
			page.model.transaction(function(tx) {
				page.model.updateRow(tx, source, {
					latitude : position.coords.latitude,
					longitude : position.coords.longitude,
				});
			}, page.error, function() {
				page.refresh();
			});
			return;
		}

		// If setting location, indicate
		if (setLocation)
			page.$("#location_relative").text("Setting location...");
		else if (!source.latitude)// If no position, indicate
			page.$("#location_relative").html('Unspecified location');
		else if (!position)// If waiting for position
			page.$("#location_relative").html('<img src="images/ajax-loader.gif"/>Waiting for GPS');
		else
			page.$("#location_relative").text(utils.getRelativeLocation(position.coords.longitude, position.coords.latitude, source.longitude, source.latitude));
	}


	this.activate = function() {
		this.refresh();

		function geolocationSuccess(pos) {
			position = pos;
			displayLocation();
		}

		function geolocationError(error) {
			//page.$("#location").text("Error finding location");
		}

		// Start location watch
		if (displayLocation) {
			locationWatchId = navigator.geolocation.watchPosition(geolocationSuccess, geolocationError, {
				maximumAge : 3000,
				enableHighAccuracy : true
			});
		}
	};


	this.deactivate = function() {
		// End location watch
		if (displayLocation) 
			navigator.geolocation.clearWatch(locationWatchId);
	};


	this.actionbarMenu = [{
		id : "delete",
		title : "Delete",
	}];

	this.actionbarTitle = "Source";

	this.actionbarMenuClick = function(id) {
		if (id == "delete") {
			if (!page.auth.canDelete(source)) {
				alert("Insufficient permissions");
				return;
			}

			if (confirm("Permanently delete source?")) {
				page.model.transaction(function(tx) {
					page.model.deleteRow(tx, source);
				}, page.error, function() {
					page.pager.closePage();
				});
			}
		}
	}

}
var pages = pages || {}

/* Edits a source */
pages.SourceEdit = function(uid) {
	var page = this;

	this.activate = function() {
		page.model.querySourceByUid(uid, function(source) {
			page.template("source_edit", {
				sourceTypes : page.model.sourceTypes
			}, function(out) {
				page.$el.html(out);
				
				page.$("#name").val(source.name);
				page.$("#desc").val(source.desc);
				page.$("#source_type").val(source.source_type);

				page.$("#save_button").on("tap", function() {
					update = {
						name : page.$("#name").val(),
						desc : page.$("#desc").val(),
						source_type : parseInt(page.$("#source_type").val())
					}

					page.model.transaction(function(tx) {
						page.model.updateRow(tx, source, update);
					}, page.error, function() {
						page.pager.closePage();
					});
				});
				page.$("#cancel_button").on("tap", function() {
					page.pager.closePage();
				});
			});
		}, page.error);
	};
}
var pages = pages || {}

/* Displays details of a source note */
pages.SourceNote = function(sourceUid, uid) {
	var page = this;
	var note;

	function setupEvents() {
		// Listen for save
		page.$("#save_button").on("tap", function() {
			// Read values
			note.note = page.$("#note").val();
			note.operational = page.$("#operational").val();
			if (note.operational === "")
				note.operational = null;

			page.model.transaction(function(tx) {
				// Insert if required
				if (!note.uid) {
					note.uid = utils.createUid();
					note.created_on = Math.floor(new Date().getTime() / 1000);
					note.source = sourceUid;
					note.created_by = page.syncServer.getUsername();
					page.model.insertRow(tx, "source_notes", note);
				} else {
					page.model.updateRow(tx, note, {
						note : note.note,
						operational : note.operational
					});
				}
			}, page.error, function() {
				page.pager.closePage();
			});
		});

		// Listen for cancel results
		page.$("#cancel_button").on("tap", function() {
			page.pager.closePage();
		});
	}


	this.activate = function(callback) {
		function displayNote() {
			page.template("source_note", note, function(out) {
				page.$el.html(out);

				page.$("#note").val(note.note);
				page.$("#operational").val(note.operational);

				if (uid && !page.auth.canEdit(note))
					page.$("#save_button").attr("disabled", true);

				setupEvents();
			}, page.error);
		}

		// If existing, load
		if (uid) {
			page.model.querySourceNoteByUid(uid, function(n) {
				note = n;
				displayNote();
			}, page.error);
		} else {
			note = {};
			displayNote();
		}
	}


	this.actionbarMenu = [{
		id : "delete",
		title : "Delete",
	}];

	this.actionbarTitle = "Source Note";

	this.actionbarMenuClick = function(id) {
		var page = this;
		if (id == "delete") {
			if (!note.uid)
				page.pager.closePage();

			if (!page.auth.canDelete(note)) {
				alert("Insufficient permissions");
				return;
			}

			if (confirm("Permanently delete note?")) {
				page.model.transaction(function(tx) {
					page.model.deleteRow(tx, note);
				}, page.error, function() {
					page.pager.closePage();
				});
			}
		}
	}

}
var pages = pages || {}

/* Displays a list of nearby sources */
pages.Sources = function() {
    var page = this;

    this.create = function(callback) {
        this.template("sources", null, function(out) {
            page.$el.html(out);

            Pager.makeTappable(page.$("#table"), function(row) {
                if (row.id.length>0)
                    page.pager.loadPage("Source", [row.id]);
            });
            callback();
        });
    };

    this.activate = function() {
        this.refresh("");
    };

    this.refresh = function(query) {
        function displaySources(sources) {
            page.template("sources_rows", {
                "rows" : sources.length > 0 ? sources : null,
            }, page.$("#table"));
        }

        // Get location
        function queryByLocation(position) {
            // Handle case of no position
            if (!position) {
                // Display unlocated sources if logged in
                if (page.syncServer.loggedIn()) {
                    page.model.queryUnlocatedSources(page.syncServer.getUsername(), query, function(rows) {
                        displaySources(rows);
                    }, page.error);
                }
                return;
            }

            page.$("#message_bar").hide();
            
            // If lower accuracy, discard
            if (page.location && page.location.coords.accuracy < position.coords.accuracy)
                return;

            // Save location
            page.location = position;

            // Query sources
            page.model.queryNearbySources(position.coords.latitude, position.coords.longitude, query, function(rows) {
                // Add unlocated sources to bottom
                if (page.syncServer.loggedIn()) {
                    page.model.queryUnlocatedSources(page.syncServer.getUsername(), query, function(rows2) {
                        displaySources(rows.concat(rows2));
                    }, page.error);
                } else
                    displaySources(rows);
            }, page.error);
        }

        function locationError(position) {
            page.$("#message_text").text("Unable to get location: only unlocated sources displayed.");
            page.$("#message_bar").show();

            if (!page.syncServer.loggedIn()) {
                alert("Unable to determine position and not logged in, so no sources shown.");
            }
        }

        if (!page.location) {
            // Set status
            page.$("#message_text").text("Obtaining location...");
            page.$("#message_bar").show();
            
            // Immediately query unlocated sources
            queryByLocation();
            
            // Both have to fail to trigger close
            var locationError2 = _.after(2, locationError);
            
            // Get both high and low accuracy, as low is sufficient for initial display
            navigator.geolocation.getCurrentPosition(queryByLocation, locationError2, {
                maximumAge : 3600*24,
                timeout : 10000,
                enableHighAccuracy : false
            });

            navigator.geolocation.getCurrentPosition(queryByLocation, locationError2, {
                maximumAge : 3600,
                timeout : 30000,
                enableHighAccuracy : true
            });
        } else
            queryByLocation(page.location);
    };

    this.actionbarMenu = [{
        id : "new",
        title : "New",
        icon : "images/new.png",
        ifRoom : true
    }, {
        id : "search",
        title : "Search",
        icon : "images/search.png",
        ifRoom : true
    }];

    this.actionbarTitle = "Sources";

    this.actionbarMenuClick = function(id) {
        if (id == "search")
            this.refresh(prompt("Search for:"));
        else if (id == "new") {
            if (!page.auth.canAdd("sources")) {
                alert("Insufficient permissions");
            } else
                page.pager.loadPage("NewSource");
        } else
            alert(id);
    }

}

var pages = pages || {}

/* Displays details of a test */
pages.Test = function() {
	this.displayTest = function() {
		var page = this;

		// Display photo
		new PhotoDisplayer(page, page.$("#photo"), page.test, page.error);

		if (!page.auth.canEdit(page.test)) {
			page.$("#edit_results_button, #record_results_button, #edit_notes_button").attr("disabled", true);
		}

		// Listen for record/edit results
		page.$("#edit_results_button, #record_results_button").on("tap", function() {
			page.$("#display_results").hide();
			page.$("#edit_results").show();
		});

		// Listen for save results
		page.$("#save_results_button").on("tap", function() {
			var results = page.saveResults();
			
			// Allow cancelling
			if (!results)
				return;

			// Convert to json and save, marking test as read
			var update = {
				results : JSON.stringify(results)
			}

			if (!page.test.read_on)
				update.read_on = Math.floor(new Date().getTime() / 1000);

			page.model.transaction(function(tx) {
				page.model.updateRow(tx, page.test, update);
			}, page.error, function() {
				page.refresh();
			});
		});

		// Listen for cancel results
		page.$("#cancel_results_button").on("tap", function() {
			page.$("#edit_results").hide();
			page.$("#display_results").show();
		});

		// Display results
		page.displayResults();

		// Listen for edit notes
		page.$("#edit_notes_button").on("tap", function() {
			var notes = prompt("Enter notes", page.test.notes);
			if (notes !== null) {
				page.model.transaction(function(tx) {
					page.model.updateRow(tx, page.test, {
						notes : notes
					});
				}, page.error, function() {
					page.refresh();
				});
			}
		});

	}


	this.activate = function() {
		this.refresh();
	}

	this.createTemplateView = function(test) {
		return _.clone(test);
	}

	this.refresh = function() {
		var page = this;

		// Query test
		page.model.queryTestByUid(page.uid, function(t) {
			if (t == null) {
				alert("Test not found");
				page.pager.closePage();
				return;
			}

			// Parse JSON
			if (t.results)
				t.resultsData = JSON.parse(t.results);

			page.test = t;

			page.template("test_" + t.test_type, page.createTemplateView(page.test), function(out) {
				page.$el.html(out);
				page.displayTest();
			});
		}, page.error);
	}


	this.actionbarMenu = [{
		id : "delete",
		title : "Delete",
	}];

	this.actionbarTitle = "Test";

	this.actionbarMenuClick = function(id) {
		var page = this;
		if (id == "delete") {
			if (!page.auth.canDelete(page.test)) {
				alert("Insufficient permissions");
				return;
			}

			if (confirm("Permanently delete test?")) {
				page.model.transaction(function(tx) {
					page.model.deleteRow(tx, page.test);
				}, page.error, function() {
					page.pager.closePage();
				});
			}
		}
	}

}
var pages = pages || {}

/* Petrifilm */
pages.Test_0 = function(uid) {
	this.uid = uid;
	var page = this;

	this.displayResults = function() {
		if (page.test.resultsData) {
			page.$("input[name='ecoli']").val(page.test.resultsData.ecoli);
			page.$("input[name='tc']").val(page.test.resultsData.tc);
			page.$("input[name='other']").val(page.test.resultsData.other);
		}
	}


	this.saveResults = function() {
		var r = _.pick(page.test.resultsData || {}, "autoEcoli", "autoTC", "autoOther", "autoAlgo");

		r.manualEcoli = parseInt($("input[name='ecoli']").val()) || undefined;
		r.manualTC = parseInt($("input[name='tc']").val()) || undefined;
		r.manualOther = parseInt($("input[name='other']").val()) || undefined;

		return r;
	}


	this.createTemplateView = function(test) {
		var view = _.clone(test)

		if (view.resultsData) {
			var r = view.resultsData;

			r.ecoli = r.manualEcoli || r.autoEcoli;
			r.tc = r.manualTC || r.autoTC;
			r.other = r.manualOther || r.autoOther;
		}
		return view;
	}

}

pages.Test_0.prototype = new pages.Test();
pages.Test_0.prototype.constructor = pages.Test_0;
var pages = pages || {}

/* Displays details of a test */
pages.Test_1 = function(uid) {
	this.uid = uid;
	var page = this;

	this.displayResults = function() {
		if (page.test.resultsData) {
			page.$("#blue_color").toggleClass('checked', page.test.resultsData.ecoli == true);
			page.$("#yellow_color").toggleClass('checked', page.test.resultsData.tc == true);
		}
	}


	this.saveResults = function() {
		return {
			ecoli : $("#blue_color").hasClass('checked'),
			tc : $("#yellow_color").hasClass('checked')
		};
	}

}

pages.Test_1.prototype = new pages.Test();
pages.Test_1.prototype.constructor = pages.Test_1;
var pages = pages || {}

/* Displays details of a test */
pages.Test_2 = function(uid) {
	this.uid = uid;
	var page = this;

	this.displayResults = function() {
		if (page.test.resultsData) {
			page.$("#bluegreen_color").toggleClass('checked', page.test.resultsData.ecoli == true);
		}
	}


	this.saveResults = function() {
		return {
			ecoli : $("#bluegreen_color").hasClass('checked'),
		};
	}

}

pages.Test_2.prototype = new pages.Test();
pages.Test_2.prototype.constructor = pages.Test_2;
var pages = pages || {}

/* Chlorine test */
pages.Test_4 = function(uid) {
	this.uid = uid;
	var page = this;

	this.displayResults = function() {
		if (page.test.resultsData) {
			page.$("#present").toggleClass('checked', page.test.resultsData.present == true);
			$("#mgPerL").val(page.test.resultsData.mgPerL);
			if (!page.test.resultsData.present)
				page.$("#chlorine_value").hide();
		} else {
			page.$("#chlorine_value").hide();
		}
		
		page.$("#present").on('checked', function() {
			if ($("#present").hasClass('checked'))
				page.$("#chlorine_value").show();
			else
				page.$("#chlorine_value").hide();
		});
	};


	this.saveResults = function() {
		var val = {}
		val.present = $("#present").hasClass('checked');
		if (val.present && $("#mgPerL").val() != "") {
			val.mgPerL = parseFloat($("#mgPerL").val());
			if (val.mgPerL == NaN) {
				alert("Invalid value");
				return undefined;
			}
		}

		return val;
	};
};

pages.Test_4.prototype = new pages.Test();
pages.Test_4.prototype.constructor = pages.Test_4;
var pages = pages || {}

/* Generic Microbiology */
pages.Test_5 = function(uid) {
	this.uid = uid;
	var page = this;

	this.displayResults = function() {
		if (page.test.resultsData) {
			page.$("#type").val(page.test.resultsData.type);
			page.$("#value").val(page.test.resultsData.value);
		}
	}


	this.saveResults = function() {
		return {
			type : page.$("#type").val(),
			value : parseFloat(page.$("#value").val())
		};
	}

	this.createTemplateView = function(test) {
		var view = _.clone(test)

		view.types = ["ecoli", "total_coliforms", "thermotolerant_coliforms", "enterococci", "heterotrophic_plate_count", "faecal_streptococci", "clostridium_perfringens"];	
		return view;
	}
}

pages.Test_5.prototype = new pages.Test();
pages.Test_5.prototype.constructor = pages.Test_5;
var pages = pages || {}

/* Displays a list of my tests */
pages.Tests = function() {
	var page = this;

	this.create = function(callback) {
		this.template("tests", null, function(out) {
			page.$el.html(out);

			Pager.makeTappable(page.$("#table"), function(row) {
				// Get test
				page.model.queryTestByUid(row.id, function(test) {
					page.pager.loadPage("Test_" + test.test_type, [test.uid]);	
				}, page.error);
				
			});
			callback();
		});
	};

	this.activate = function() {
		this.refresh("");
	};

	this.refresh = function(query) {
		// Query sources
		// TODO query
		page.model.queryTests(page.syncServer.getUsername(), function(rows) {
			// Summarize rows
			_.each(rows, function(row) {
				row.summary = sampleanalysis.summarizeTest(row);
			});
			
			page.template("tests_rows", {
				"rows" : rows
			}, page.$("#table"));
		}, page.error);
	};

	this.actionbarMenu = [{
		id : "new",
		title : "New",
		icon : "images/new.png",
		ifRoom : true
	}];

	this.actionbarTitle = "My Tests";

	this.actionbarMenuClick = function(id) {
		if (id == "new")
		{
			if (confirm("Create a test not associated with a source?"))
				this.pager.loadPage("NewTest");
		}
	}

}

